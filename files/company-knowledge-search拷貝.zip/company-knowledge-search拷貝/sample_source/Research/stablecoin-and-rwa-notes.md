# Stablecoin & RWA Market Notes

Internal research notes, maintained by the Digital Assets Product team.

## Stablecoins

USDT remains the most widely circulated stablecoin relevant to our
custody and settlement flows. As first flagged in the Web3 Steering
Committee deck (2026-01-15), reserve transparency is the main ongoing
monitoring item -- see the Custody Framework's stablecoin reserve
section for the escalation threshold.

台灣市場對穩定幣的關注持續升高，USDT 的鏈上流通量在過去一季顯著成長。

## RWA Tokenization

Real World Asset (RWA) tokenization continues to gain traction with
institutional players. Potential near-term angle: a tokenized
short-term bond fund, pending confirmation of a licensed custody
partner (see custody vendor evaluation, including SBI custody).

## Regulatory Watch

Binance's Taiwan VASP application is the most time-sensitive item on
our regulatory radar this quarter. Track against the milestone table
in the Steering Committee deck.
