"""Search tests: FTS5 ranking, the short-CJK-term LIKE fallback, phrase
queries, filters, and that source metadata survives into search results."""

from __future__ import annotations

from src.indexing import sync_source_folder
from src.search import SearchFilters, parse_query_terms, search


def _index_corpus(source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file):
    make_pptx(
        source_folder / "Web3" / "deck.pptx",
        [
            ("VASP 申請進度", ["Binance 已準備申請台灣 VASP 執照。"]),
            ("Custody", ["初步評估 SBI custody 作為數位資產保管方案之一。"]),
        ],
    )
    make_pdf(
        source_folder / "Legal" / "custody.pdf",
        ["Digital asset custody requires segregation controls and audit trails."],
    )
    make_docx(
        source_folder / "Meetings" / "notes.docx",
        [("Custody Vendor", ["Team to finalize evaluation of SBI custody readiness."])],
    )
    make_text_file(
        source_folder / "notes.md",
        "找出所有提到 USDT 的資料，並確認最早提及的會議記錄。",
    )
    sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)


class TestParseQueryTerms:
    def test_splits_on_whitespace(self):
        assert parse_query_terms("Binance VASP") == ["Binance", "VASP"]

    def test_quoted_phrase_stays_together(self):
        assert parse_query_terms('"SBI custody"') == ["SBI custody"]

    def test_mixed_quoted_and_plain(self):
        assert parse_query_terms('"SBI custody" readiness') == ["SBI custody", "readiness"]

    def test_empty_query_returns_no_terms(self):
        assert parse_query_terms("   ") == []


class TestSearch:
    def test_search_finds_english_term_across_documents(self, source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file):
        _index_corpus(source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file)
        results = search(db_conn, "custody")

        matched_files = {r.source_file for r in results}
        assert "custody.pdf" in matched_files
        assert "notes.docx" in matched_files

    def test_search_finds_binance_with_correct_slide_provenance(self, source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file):
        _index_corpus(source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file)
        results = search(db_conn, "Binance")

        assert len(results) >= 1
        top = results[0]
        assert top.source_file == "deck.pptx"
        assert top.slide_number == 1
        assert top.relative_path == "Web3/deck.pptx"

    def test_search_short_cjk_term_uses_like_fallback_and_still_matches(
        self, source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file
    ):
        _index_corpus(source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file)
        results = search(db_conn, "申請")  # 2-character term, too short for trigram FTS
        assert any("deck.pptx" == r.source_file for r in results)

    def test_search_mixed_chinese_english_query(self, source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file):
        _index_corpus(source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file)
        results = search(db_conn, "USDT")
        assert any(r.source_file == "notes.md" for r in results)

    def test_quoted_phrase_search_is_exact_substring(self, source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file):
        _index_corpus(source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file)
        results = search(db_conn, '"SBI custody"')
        assert len(results) >= 1
        assert all("SBI custody" in r.text for r in results)

    def test_no_match_returns_empty(self, source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file):
        _index_corpus(source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file)
        results = search(db_conn, "nonexistenttermxyz")
        assert results == []

    def test_filter_by_document_type(self, source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file):
        _index_corpus(source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file)
        results = search(db_conn, "custody", filters=SearchFilters(document_type="pdf"))
        assert results
        assert all(r.document_type == "pdf" for r in results)

    def test_filter_by_path_contains(self, source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file):
        _index_corpus(source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file)
        results = search(db_conn, "custody", filters=SearchFilters(path_contains="Meetings"))
        assert results
        assert all("Meetings" in r.relative_path for r in results)

    def test_filter_by_filename_contains(self, source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file):
        _index_corpus(source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file)
        results = search(db_conn, "custody", filters=SearchFilters(filename_contains="custody.pdf"))
        assert results
        assert all(r.source_file == "custody.pdf" for r in results)

    def test_search_result_snippet_highlights_match_marker(self, source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file):
        from src.search import SNIPPET_MARK_START

        _index_corpus(source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file)
        results = search(db_conn, "custody")
        assert any(SNIPPET_MARK_START in r.snippet for r in results)

    def test_empty_query_returns_no_results(self, source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file):
        _index_corpus(source_folder, db_conn, make_pdf, make_pptx, make_docx, make_text_file)
        assert search(db_conn, "   ") == []
