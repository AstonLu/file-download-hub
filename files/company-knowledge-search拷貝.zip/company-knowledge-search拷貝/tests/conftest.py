"""Shared pytest fixtures: an isolated SQLite database plus small factory
fixtures for generating minimal PDF/PPTX/DOCX/TXT/MD test documents.

Every fixture writes into pytest's ``tmp_path``, so tests never touch the
real ``sample_source/`` corpus or ``data/`` folder and can run in any order.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.database import connect, initialize_schema  # noqa: E402


@pytest.fixture()
def db_conn(tmp_path):
    conn = connect(tmp_path / "test.db")
    initialize_schema(conn)
    yield conn
    conn.close()


@pytest.fixture()
def source_folder(tmp_path) -> Path:
    folder = tmp_path / "source"
    folder.mkdir()
    return folder


@pytest.fixture()
def make_pdf():
    def _make(path: Path, page_texts: list[str]) -> Path:
        import pymupdf

        doc = pymupdf.open()
        for text in page_texts:
            page = doc.new_page()
            page.insert_textbox(pymupdf.Rect(50, 50, 550, 780), text, fontsize=11, fontname="helv")
        path.parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(path))
        doc.close()
        return path

    return _make


@pytest.fixture()
def make_blank_pdf():
    """A PDF with pages but no text -- exercises the 'scanned PDF' warning path."""

    def _make(path: Path, page_count: int = 1) -> Path:
        import pymupdf

        doc = pymupdf.open()
        for _ in range(page_count):
            doc.new_page()
        path.parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(path))
        doc.close()
        return path

    return _make


@pytest.fixture()
def make_corrupt_pdf():
    def _make(path: Path) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"%PDF-1.4\nnot a real pdf stream\n%%EOF")
        return path

    return _make


@pytest.fixture()
def make_pptx():
    def _make(path: Path, slides: list[tuple[str, list[str]]]) -> Path:
        """slides: list of (title, [bullet lines])."""
        from pptx import Presentation

        prs = Presentation()
        layout = prs.slide_layouts[1]
        for title, bullets in slides:
            slide = prs.slides.add_slide(layout)
            slide.shapes.title.text = title
            body = slide.placeholders[1].text_frame
            if bullets:
                body.text = bullets[0]
                for bullet in bullets[1:]:
                    p = body.add_paragraph()
                    p.text = bullet
        path.parent.mkdir(parents=True, exist_ok=True)
        prs.save(str(path))
        return path

    return _make


@pytest.fixture()
def make_docx():
    def _make(path: Path, sections: list[tuple[str, list[str]]]) -> Path:
        """sections: list of (heading, [paragraph texts])."""
        import docx

        document = docx.Document()
        for heading, paragraphs in sections:
            if heading:
                document.add_heading(heading, level=2)
            for paragraph_text in paragraphs:
                document.add_paragraph(paragraph_text)
        path.parent.mkdir(parents=True, exist_ok=True)
        document.save(str(path))
        return path

    return _make


@pytest.fixture()
def make_text_file():
    def _make(path: Path, content: str) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    return _make
