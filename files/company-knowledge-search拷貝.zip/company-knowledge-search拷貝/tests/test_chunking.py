"""Chunking tests: provenance is preserved, chunks never mix across units,
and boundary conditions (short text, overlap, CJK) behave deterministically."""

from __future__ import annotations

import pytest

from src.chunking import chunk_units
from src.models import ExtractedUnit


def test_short_unit_becomes_single_chunk():
    units = [ExtractedUnit(text="Short text.", page_number=1)]
    chunks = chunk_units(units, chunk_size=100, chunk_overlap=20)
    assert len(chunks) == 1
    assert chunks[0].text == "Short text."
    assert chunks[0].page_number == 1


def test_long_unit_is_split_into_multiple_chunks():
    text = " ".join(f"word{i}" for i in range(200))
    units = [ExtractedUnit(text=text, page_number=5)]
    chunks = chunk_units(units, chunk_size=100, chunk_overlap=20)

    assert len(chunks) > 1
    assert all(c.page_number == 5 for c in chunks)
    assert all(len(c.text) <= 100 for c in chunks)


def test_chunk_index_is_sequential_across_whole_document():
    units = [
        ExtractedUnit(text="a " * 100, page_number=1),
        ExtractedUnit(text="b " * 100, page_number=2),
    ]
    chunks = chunk_units(units, chunk_size=50, chunk_overlap=10)
    indices = [c.chunk_index for c in chunks]
    assert indices == list(range(len(chunks)))


def test_chunks_never_mix_text_across_units():
    units = [
        ExtractedUnit(text="ALPHA content here, " * 20, page_number=1),
        ExtractedUnit(text="BETA content here, " * 20, page_number=2),
    ]
    chunks = chunk_units(units, chunk_size=80, chunk_overlap=15)

    for chunk in chunks:
        has_alpha = "ALPHA" in chunk.text
        has_beta = "BETA" in chunk.text
        assert not (has_alpha and has_beta), f"chunk mixed content across units: {chunk.text!r}"
        if has_alpha:
            assert chunk.page_number == 1
        if has_beta:
            assert chunk.page_number == 2


def test_slide_and_section_metadata_preserved():
    units = [ExtractedUnit(text="c " * 100, slide_number=3, section="Custody")]
    chunks = chunk_units(units, chunk_size=50, chunk_overlap=10)
    assert all(c.slide_number == 3 and c.section == "Custody" for c in chunks)


def test_empty_units_are_skipped():
    units = [ExtractedUnit(text="", page_number=1), ExtractedUnit(text="   ", page_number=2)]
    chunks = chunk_units(units, chunk_size=100, chunk_overlap=20)
    assert chunks == []


def test_cjk_text_without_spaces_is_chunked_by_character():
    cjk_text = "這是一段沒有空格的中文測試文字，用來確認分段功能對中文也能正常運作。" * 5
    units = [ExtractedUnit(text=cjk_text, page_number=1)]
    chunks = chunk_units(units, chunk_size=40, chunk_overlap=10)
    assert len(chunks) > 1
    assert all(len(c.text) <= 40 for c in chunks)
    # rejoining without overlap awareness should still cover the source content
    assert all(c.page_number == 1 for c in chunks)


def test_overlap_produces_shared_content_between_consecutive_chunks():
    text = " ".join(f"token{i}" for i in range(100))
    units = [ExtractedUnit(text=text, page_number=1)]
    chunks = chunk_units(units, chunk_size=60, chunk_overlap=20)

    assert len(chunks) >= 2
    first_words = set(chunks[0].text.split())
    second_words = set(chunks[1].text.split())
    assert first_words & second_words, "expected overlapping content between consecutive chunks"


def test_no_infinite_loop_on_many_boundary_sizes():
    text = "x" * 997  # deliberately awkward length vs. chunk_size/overlap
    units = [ExtractedUnit(text=text, page_number=1)]
    chunks = chunk_units(units, chunk_size=100, chunk_overlap=99)
    assert len(chunks) > 0  # must terminate and produce output


@pytest.mark.parametrize(
    "chunk_size,chunk_overlap",
    [(0, 0), (-10, 0), (100, 100), (100, 150)],
)
def test_invalid_chunk_settings_raise(chunk_size, chunk_overlap):
    units = [ExtractedUnit(text="some text", page_number=1)]
    with pytest.raises(ValueError):
        chunk_units(units, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
