"""Config load/save round-trip tests."""

from __future__ import annotations

from src.config import AppConfig, load_config, save_config


def test_load_config_creates_defaults_when_missing(tmp_path):
    config_path = tmp_path / "config.json"
    config = load_config(config_path)

    assert config.source_folder == ""
    assert config.chunk_size > 0
    assert config_path.exists()  # defaults are persisted immediately


def test_save_and_load_round_trip(tmp_path):
    config_path = tmp_path / "config.json"
    original = AppConfig(source_folder="/some/path", db_path="/some/db.sqlite", chunk_size=800, chunk_overlap=100)
    save_config(original, config_path)

    loaded = load_config(config_path)
    assert loaded == original


def test_load_config_ignores_unknown_keys(tmp_path):
    config_path = tmp_path / "config.json"
    config_path.write_text('{"source_folder": "/x", "unknown_field": 123}', encoding="utf-8")

    config = load_config(config_path)
    assert config.source_folder == "/x"


def test_load_config_handles_corrupt_json(tmp_path):
    config_path = tmp_path / "config.json"
    config_path.write_text("{not valid json", encoding="utf-8")

    config = load_config(config_path)  # must not raise
    assert isinstance(config, AppConfig)


def test_config_preserves_unicode_paths(tmp_path):
    config_path = tmp_path / "config.json"
    original = AppConfig(source_folder="/專案/文件夾")
    save_config(original, config_path)

    loaded = load_config(config_path)
    assert loaded.source_folder == "/專案/文件夾"
