"""Sync/indexing integration tests: covers the incremental-indexing
contract end to end (new/unchanged/modified/deleted), source metadata
correctness, transactional integrity, and per-document failure isolation."""

from __future__ import annotations

import time

from src.indexing import sync_source_folder


def _chunk_rows(conn):
    return conn.execute("SELECT * FROM chunks").fetchall()


def _document_rows(conn):
    return conn.execute("SELECT * FROM documents").fetchall()


def test_new_files_are_indexed_with_correct_counts(source_folder, db_conn, make_pdf, make_pptx):
    make_pdf(source_folder / "Legal" / "custody.pdf", ["Digital asset custody requires segregation controls."])
    make_pptx(source_folder / "Web3" / "deck.pptx", [("VASP", ["Binance plans a VASP application."])])

    report = sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)

    assert report.new == 2
    assert report.updated == 0
    assert report.deleted == 0
    assert report.failed == 0
    assert len(_document_rows(db_conn)) == 2
    assert len(_chunk_rows(db_conn)) >= 2


def test_source_metadata_is_recorded_correctly(source_folder, db_conn, make_pptx):
    make_pptx(
        source_folder / "Web3" / "deck.pptx",
        [("VASP Update", ["Binance plans a VASP application in Taiwan."])],
    )
    sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)

    doc = _document_rows(db_conn)[0]
    assert doc["relative_path"] == "Web3/deck.pptx"
    assert doc["filename"] == "deck.pptx"
    assert doc["extension"] == ".pptx"
    assert doc["extraction_status"] == "ok"
    assert doc["content_hash"]
    assert doc["indexed_at"]

    chunk = _chunk_rows(db_conn)[0]
    assert chunk["document_type"] == "pptx"
    assert chunk["slide_number"] == 1
    assert chunk["section"] == "VASP Update"
    assert chunk["page_number"] is None
    assert chunk["relative_path"] == "Web3/deck.pptx"
    assert chunk["source_file"] == "deck.pptx"


def test_repeated_sync_with_no_changes_does_not_reparse(source_folder, db_conn, make_text_file):
    make_text_file(source_folder / "notes.txt", "Some notes about Binance and VASP.")

    first_report = sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)
    assert first_report.new == 1
    indexed_at_first = _document_rows(db_conn)[0]["indexed_at"]

    second_report = sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)
    assert second_report.new == 0
    assert second_report.updated == 0
    assert second_report.unchanged == 1
    indexed_at_second = _document_rows(db_conn)[0]["indexed_at"]

    assert indexed_at_first == indexed_at_second  # proves it was not re-parsed/re-written


def test_modified_file_is_reindexed_and_old_chunks_replaced(source_folder, db_conn, make_text_file):
    path = make_text_file(source_folder / "notes.txt", "Original content about Binance.")
    sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)

    original_doc_id = _document_rows(db_conn)[0]["id"]
    assert any("Binance" in row["text"] for row in _chunk_rows(db_conn))

    time.sleep(0.01)
    path.write_text("Completely different content about VASP licensing only.", encoding="utf-8")

    report = sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)
    assert report.updated == 1
    assert report.new == 0

    docs = _document_rows(db_conn)
    assert len(docs) == 1  # no duplicate row
    chunks = _chunk_rows(db_conn)
    assert all("Binance" not in row["text"] for row in chunks)
    assert any("VASP" in row["text"] for row in chunks)
    assert all(row["document_id"] == docs[0]["id"] for row in chunks)


def test_deleted_file_removes_document_and_chunks(source_folder, db_conn, make_text_file):
    path = make_text_file(source_folder / "notes.txt", "Content about custody controls.")
    sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)
    assert len(_document_rows(db_conn)) == 1
    assert len(_chunk_rows(db_conn)) >= 1

    path.unlink()
    report = sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)

    assert report.deleted == 1
    assert _document_rows(db_conn) == []
    assert _chunk_rows(db_conn) == []

    # the FTS index must be empty too, not just the base table
    fts_count = db_conn.execute("SELECT COUNT(*) FROM chunks_fts").fetchone()[0]
    assert fts_count == 0


def test_one_corrupt_file_does_not_abort_sync_of_others(source_folder, db_conn, make_text_file):
    make_text_file(source_folder / "good.txt", "Valid content about stablecoins.")
    corrupt_path = source_folder / "corrupt.pdf"
    corrupt_path.write_bytes(b"%PDF-1.4\nnot a real pdf\n%%EOF")

    report = sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)

    assert report.new == 1  # good.txt
    assert report.failed == 1  # corrupt.pdf
    assert any("corrupt.pdf" in path for path, _ in report.failures)

    docs = {row["relative_path"]: row for row in _document_rows(db_conn)}
    assert docs["good.txt"]["extraction_status"] == "ok"
    assert docs["corrupt.pdf"]["extraction_status"] == "failed"
    assert docs["corrupt.pdf"]["status_message"]

    # the failed document contributed zero chunks
    failed_chunks = db_conn.execute(
        "SELECT COUNT(*) FROM chunks WHERE relative_path = ?", ("corrupt.pdf",)
    ).fetchone()[0]
    assert failed_chunks == 0


def test_blank_pdf_is_indexed_with_warning_not_failure(source_folder, db_conn, make_blank_pdf):
    make_blank_pdf(source_folder / "scanned.pdf", page_count=1)
    report = sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)

    assert report.new == 1
    assert report.failed == 0
    assert len(report.warnings) == 1

    doc = _document_rows(db_conn)[0]
    assert doc["extraction_status"] == "warning"


def test_nonexistent_source_folder_fails_gracefully(tmp_path, db_conn):
    missing = tmp_path / "does_not_exist"
    report = sync_source_folder(db_conn, missing, chunk_size=500, chunk_overlap=50)
    assert report.failed == 1
    assert report.new == 0
