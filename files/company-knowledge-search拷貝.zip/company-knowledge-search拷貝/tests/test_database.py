"""Database-layer tests: transaction rollback and the "clear index"
danger-zone operation used by the Streamlit sidebar."""

from __future__ import annotations

import pytest

from src.database import clear_all, connect, get_stats, initialize_schema, transaction
from src.indexing import sync_source_folder


def test_clear_all_removes_documents_chunks_and_fts_entries(source_folder, db_conn, make_text_file):
    make_text_file(source_folder / "a.txt", "Content about Binance and VASP.")
    make_text_file(source_folder / "b.txt", "Content about custody controls.")
    sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)

    stats_before = get_stats(db_conn)
    assert stats_before["document_count"] == 2
    assert stats_before["chunk_count"] >= 2

    clear_all(db_conn)

    stats_after = get_stats(db_conn)
    assert stats_after["document_count"] == 0
    assert stats_after["chunk_count"] == 0

    fts_count = db_conn.execute("SELECT COUNT(*) FROM chunks_fts").fetchone()[0]
    assert fts_count == 0


def test_clear_all_does_not_touch_source_files(source_folder, db_conn, make_text_file):
    path = make_text_file(source_folder / "a.txt", "Content about Binance.")
    sync_source_folder(db_conn, source_folder, chunk_size=500, chunk_overlap=50)

    clear_all(db_conn)

    assert path.exists()
    assert path.read_text(encoding="utf-8") == "Content about Binance."


def test_transaction_rolls_back_on_error(db_conn):
    db_conn.execute(
        """
        INSERT INTO documents (
            absolute_path, relative_path, filename, extension, file_size,
            file_modified_at, content_hash, indexed_at, parser_version,
            extraction_status, status_message
        ) VALUES ('/a', 'a.txt', 'a.txt', '.txt', 1, '2026-01-01T00:00:00+00:00', 'h', '2026-01-01T00:00:00+00:00', '1', 'ok', NULL)
        """
    )
    db_conn.commit()

    with pytest.raises(Exception):
        with transaction(db_conn):
            db_conn.execute("DELETE FROM documents WHERE relative_path = 'a.txt'")
            # duplicate relative_path violates the UNIQUE constraint, forcing a rollback
            db_conn.execute(
                """
                INSERT INTO documents (
                    absolute_path, relative_path, filename, extension, file_size,
                    file_modified_at, content_hash, indexed_at, parser_version,
                    extraction_status, status_message
                ) VALUES ('/b', 'b.txt', 'b.txt', '.txt', 1, '2026-01-01T00:00:00+00:00', 'h', '2026-01-01T00:00:00+00:00', '1', 'ok', NULL)
                """
            )
            raise RuntimeError("simulated failure mid-transaction")

    # the DELETE must have been rolled back along with everything else
    remaining = db_conn.execute("SELECT COUNT(*) FROM documents WHERE relative_path = 'a.txt'").fetchone()[0]
    assert remaining == 1
    leaked = db_conn.execute("SELECT COUNT(*) FROM documents WHERE relative_path = 'b.txt'").fetchone()[0]
    assert leaked == 0


def test_connect_allows_use_across_threads(tmp_path):
    """Regression test: Streamlit can resume a cached connection on a
    different worker thread than the one that created it. sqlite3
    connections must be opened with check_same_thread=False or this
    raises ProgrammingError."""
    import threading

    conn = connect(tmp_path / "threaded.db")
    initialize_schema(conn)

    errors = []

    def query_from_other_thread():
        try:
            conn.execute("SELECT COUNT(*) FROM documents").fetchone()
        except Exception as exc:  # pragma: no cover - failure path
            errors.append(exc)

    thread = threading.Thread(target=query_from_other_thread)
    thread.start()
    thread.join()

    assert not errors, f"cross-thread query failed: {errors}"
    conn.close()
