"""Parser tests: correct extraction for each supported format, plus
graceful handling of corrupt/empty/encrypted-like failure cases."""

from __future__ import annotations

from src.parsers.docx import DocxParser
from src.parsers.pdf import PdfParser
from src.parsers.pptx import PptxParser
from src.parsers.text import TextParser


class TestPdfParser:
    def test_extracts_text_per_page(self, tmp_path, make_pdf):
        path = make_pdf(tmp_path / "doc.pdf", ["Page one content about custody.", "Page two mentions VASP."])
        result = PdfParser().parse(path)

        assert result.status == "ok"
        assert len(result.units) == 2
        assert result.units[0].page_number == 1
        assert result.units[1].page_number == 2
        assert "custody" in result.units[0].text
        assert "VASP" in result.units[1].text

    def test_page_numbers_are_one_based(self, tmp_path, make_pdf):
        path = make_pdf(tmp_path / "doc.pdf", ["a", "b", "c"])
        result = PdfParser().parse(path)
        assert [u.page_number for u in result.units] == [1, 2, 3]

    def test_blank_pdf_reports_warning_not_failure(self, tmp_path, make_blank_pdf):
        path = make_blank_pdf(tmp_path / "scanned.pdf", page_count=2)
        result = PdfParser().parse(path)

        assert result.status == "warning"
        assert "no extractable text" in (result.message or "").lower()
        assert len(result.units) == 2  # units still exist, just empty

    def test_corrupt_pdf_fails_without_raising(self, tmp_path, make_corrupt_pdf):
        path = make_corrupt_pdf(tmp_path / "corrupt.pdf")
        result = PdfParser().parse(path)

        assert result.status == "failed"
        assert result.message

    def test_missing_file_fails_without_raising(self, tmp_path):
        result = PdfParser().parse(tmp_path / "does_not_exist.pdf")
        assert result.status == "failed"


class TestPptxParser:
    def test_extracts_text_per_slide_with_title(self, tmp_path, make_pptx):
        path = make_pptx(
            tmp_path / "deck.pptx",
            [
                ("VASP Update", ["Binance is preparing a VASP application."]),
                ("Custody", ["SBI custody is under evaluation."]),
            ],
        )
        result = PptxParser().parse(path)

        assert result.status == "ok"
        assert len(result.units) == 2
        assert result.units[0].slide_number == 1
        assert result.units[0].section == "VASP Update"
        assert "Binance" in result.units[0].text
        assert result.units[1].slide_number == 2
        assert result.units[1].section == "Custody"
        assert "SBI custody" in result.units[1].text

    def test_empty_presentation_warns(self, tmp_path, make_pptx):
        path = make_pptx(tmp_path / "empty.pptx", [])
        result = PptxParser().parse(path)
        assert result.status == "warning"

    def test_corrupt_pptx_fails_without_raising(self, tmp_path):
        path = tmp_path / "corrupt.pptx"
        path.write_bytes(b"not a real zip/pptx")
        result = PptxParser().parse(path)
        assert result.status == "failed"
        assert result.message


class TestDocxParser:
    def test_extracts_paragraphs_with_section_context(self, tmp_path, make_docx):
        path = make_docx(
            tmp_path / "notes.docx",
            [
                ("VASP Application", ["Management requested a readiness assessment."]),
                ("Custody Vendor", ["SBI custody evaluation is in progress."]),
            ],
        )
        result = DocxParser().parse(path)

        assert result.status == "ok"
        sections = {u.section for u in result.units}
        assert "VASP Application" in sections
        assert "Custody Vendor" in sections
        assert result.units[0].page_number is None  # docx never fabricates page numbers

    def test_empty_document_warns(self, tmp_path, make_docx):
        path = make_docx(tmp_path / "empty.docx", [])
        result = DocxParser().parse(path)
        assert result.status == "warning"

    def test_corrupt_docx_fails_without_raising(self, tmp_path):
        path = tmp_path / "corrupt.docx"
        path.write_bytes(b"not a real zip/docx")
        result = DocxParser().parse(path)
        assert result.status == "failed"
        assert result.message


class TestTextParser:
    def test_splits_on_blank_lines(self, tmp_path, make_text_file):
        content = "First paragraph about Binance.\n\nSecond paragraph about VASP."
        path = make_text_file(tmp_path / "notes.txt", content)
        result = TextParser().parse(path)

        assert result.status == "ok"
        assert len(result.units) == 2
        assert "Binance" in result.units[0].text
        assert "VASP" in result.units[1].text

    def test_handles_utf8_chinese_text(self, tmp_path, make_text_file):
        path = make_text_file(tmp_path / "notes.md", "找出所有提到 USDT 的資料。")
        result = TextParser().parse(path)
        assert result.status == "ok"
        assert "USDT" in result.units[0].text

    def test_empty_file_warns(self, tmp_path, make_text_file):
        path = make_text_file(tmp_path / "empty.txt", "")
        result = TextParser().parse(path)
        assert result.status == "warning"

    def test_invalid_utf8_does_not_raise(self, tmp_path):
        path = tmp_path / "bad_encoding.txt"
        path.write_bytes(b"Valid start \xff\xfe invalid bytes then more text")
        result = TextParser().parse(path)
        assert result.status in ("ok", "warning")  # must not raise
