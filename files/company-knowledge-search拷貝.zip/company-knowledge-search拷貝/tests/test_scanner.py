"""Scanner tests: SHA-256 hashing and new/modified/deleted/unchanged
classification against the document registry."""

from __future__ import annotations

import time

from src.scanner import compute_sha256, scan_source_folder

SUPPORTED = {".txt", ".md"}


def test_sha256_is_deterministic_for_same_content(tmp_path):
    path = tmp_path / "a.txt"
    path.write_text("hello world", encoding="utf-8")
    assert compute_sha256(path) == compute_sha256(path)


def test_sha256_differs_for_different_content(tmp_path):
    path_a = tmp_path / "a.txt"
    path_b = tmp_path / "b.txt"
    path_a.write_text("content A", encoding="utf-8")
    path_b.write_text("content B", encoding="utf-8")
    assert compute_sha256(path_a) != compute_sha256(path_b)


def test_new_file_is_classified_to_index(source_folder, db_conn):
    (source_folder / "doc.txt").write_text("hello", encoding="utf-8")
    plan = scan_source_folder(source_folder, SUPPORTED, db_conn)

    assert len(plan.to_index) == 1
    assert plan.to_index[0].relative_path == "doc.txt"
    assert plan.to_delete == []
    assert plan.unchanged == []


def test_unsupported_extension_is_ignored(source_folder, db_conn):
    (source_folder / "doc.txt").write_text("hello", encoding="utf-8")
    (source_folder / "image.png").write_bytes(b"\x89PNG fake")
    plan = scan_source_folder(source_folder, SUPPORTED, db_conn)

    relative_paths = {m.relative_path for m in plan.to_index}
    assert relative_paths == {"doc.txt"}


def test_subfolders_are_scanned_recursively(source_folder, db_conn):
    nested = source_folder / "Web3" / "Steering"
    nested.mkdir(parents=True)
    (nested / "deck.md").write_text("content", encoding="utf-8")
    plan = scan_source_folder(source_folder, SUPPORTED, db_conn)

    assert plan.to_index[0].relative_path == "Web3/Steering/deck.md"


def _insert_document_row(conn, meta):
    conn.execute(
        """
        INSERT INTO documents (
            absolute_path, relative_path, filename, extension, file_size,
            file_modified_at, content_hash, indexed_at, parser_version,
            extraction_status, status_message
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, '1', 'ok', NULL)
        """,
        (
            meta.absolute_path,
            meta.relative_path,
            meta.filename,
            meta.extension,
            meta.file_size,
            meta.file_modified_at,
            meta.content_hash,
            "2026-01-01T00:00:00+00:00",
        ),
    )
    conn.commit()


def test_unchanged_file_is_skipped_on_second_scan(source_folder, db_conn):
    path = source_folder / "doc.txt"
    path.write_text("stable content", encoding="utf-8")

    first_plan = scan_source_folder(source_folder, SUPPORTED, db_conn)
    assert len(first_plan.to_index) == 1
    _insert_document_row(db_conn, first_plan.to_index[0])

    second_plan = scan_source_folder(source_folder, SUPPORTED, db_conn)
    assert second_plan.to_index == []
    assert second_plan.unchanged == ["doc.txt"]


def test_modified_content_is_reclassified_to_index(source_folder, db_conn):
    path = source_folder / "doc.txt"
    path.write_text("original content", encoding="utf-8")

    first_plan = scan_source_folder(source_folder, SUPPORTED, db_conn)
    _insert_document_row(db_conn, first_plan.to_index[0])

    time.sleep(0.01)
    path.write_text("modified content, quite different length", encoding="utf-8")

    second_plan = scan_source_folder(source_folder, SUPPORTED, db_conn)
    assert len(second_plan.to_index) == 1
    assert second_plan.to_index[0].relative_path == "doc.txt"
    assert second_plan.unchanged == []


def test_deleted_file_is_classified_to_delete(source_folder, db_conn):
    path = source_folder / "doc.txt"
    path.write_text("content", encoding="utf-8")

    first_plan = scan_source_folder(source_folder, SUPPORTED, db_conn)
    _insert_document_row(db_conn, first_plan.to_index[0])

    path.unlink()

    second_plan = scan_source_folder(source_folder, SUPPORTED, db_conn)
    assert second_plan.to_delete == ["doc.txt"]
    assert second_plan.to_index == []


def test_resaved_file_with_identical_content_stays_unchanged(source_folder, db_conn):
    """Same bytes, different mtime/size-precheck path -- hash comparison
    should still classify this as unchanged (avoids unnecessary re-parsing)."""
    path = source_folder / "doc.txt"
    path.write_text("identical content", encoding="utf-8")

    first_plan = scan_source_folder(source_folder, SUPPORTED, db_conn)
    meta = first_plan.to_index[0]
    _insert_document_row(db_conn, meta)

    # Simulate a resave that changes mtime but not content: mutate the
    # stored file_modified_at to something else so the fast precheck
    # (size+mtime) misses and hash comparison must catch it instead.
    db_conn.execute(
        "UPDATE documents SET file_modified_at = ? WHERE relative_path = ?",
        ("2020-01-01T00:00:00+00:00", "doc.txt"),
    )
    db_conn.commit()

    second_plan = scan_source_folder(source_folder, SUPPORTED, db_conn)
    assert second_plan.unchanged == ["doc.txt"]
    assert second_plan.to_index == []
