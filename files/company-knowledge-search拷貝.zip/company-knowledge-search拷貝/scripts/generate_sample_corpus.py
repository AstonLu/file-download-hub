"""Generate a small, synthetic sample corpus for testing and demos.

Everything in here is fictional business content invented for this
project. It intentionally spreads related facts (Binance's VASP plans, an
SBI custody evaluation, USDT reserve concerns) across different files and
dates so end-to-end retrieval and "which file mentioned this first"
scenarios can be tested without any real corporate data.

Run:
    python scripts/generate_sample_corpus.py
"""

from __future__ import annotations

import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

SAMPLE_DIR = PROJECT_ROOT / "sample_source"


def _set_mtime(path: Path, iso_date: str) -> None:
    """Set a file's modified time deterministically, for QA/date-filter testing."""
    dt = datetime.fromisoformat(iso_date).replace(tzinfo=timezone.utc)
    timestamp = dt.timestamp()
    os.utime(path, (timestamp, timestamp))


def build_pptx() -> None:
    from pptx import Presentation
    from pptx.util import Inches, Pt

    folder = SAMPLE_DIR / "Web3"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "2026 Web3 Steering Committee.pptx"

    prs = Presentation()
    title_layout = prs.slide_layouts[0]
    content_layout = prs.slide_layouts[1]

    slide = prs.slides.add_slide(title_layout)
    slide.shapes.title.text = "2026 Web3 Steering Committee"
    slide.placeholders[1].text = "Quarterly digital asset strategy review · 2026-01-15"

    def add_slide(title: str, bullets: list[str]) -> None:
        s = prs.slides.add_slide(content_layout)
        s.shapes.title.text = title
        body = s.placeholders[1].text_frame
        body.text = bullets[0]
        for bullet in bullets[1:]:
            p = body.add_paragraph()
            p.text = bullet
            p.level = 0

    add_slide(
        "Agenda",
        [
            "VASP licensing update",
            "Custody vendor evaluation",
            "Stablecoin market observations",
            "RWA tokenization opportunity",
        ],
    )
    add_slide(
        "VASP 申請進度",
        [
            "Binance 已準備申請台灣 VASP 執照，預計於 2026 Q2 送件。",
            "法遵團隊正在準備反洗錢（AML）與客戶盡職調查（KYC）文件。",
            "需與金管會保持溝通，確認申請時程。",
        ],
    )
    add_slide(
        "託管服務評估 (Custody Vendor Evaluation)",
        [
            "初步評估 SBI custody 作為數位資產保管方案之一。",
            "Digital asset custody requires segregation controls and independent audit trails.",
            "下一步：安排 SBI custody 技術簡報與盡職調查。",
        ],
    )
    add_slide(
        "穩定幣觀察 (Stablecoin Watch)",
        [
            "USDT 為市場上流通量最大的穩定幣，需持續關注其準備金揭露報告。",
            "USDT reserve transparency remains a key monitoring item for the compliance team.",
        ],
    )
    add_slide(
        "RWA Tokenization",
        [
            "Real World Asset (RWA) tokenization is an emerging opportunity for institutional adoption.",
            "Potential pilot: tokenized short-term bond fund in partnership with a licensed custodian.",
        ],
    )

    # A table on one slide, to exercise table-shape extraction.
    table_slide = prs.slides.add_slide(prs.slide_layouts[5])
    table_slide.shapes.title.text = "VASP 申請時程 (Timeline)"
    rows, cols = 4, 2
    left, top, width, height = Inches(1), Inches(1.8), Inches(8), Inches(2)
    table_shape = table_slide.shapes.add_table(rows, cols, left, top, width, height)
    table = table_shape.table
    table.cell(0, 0).text = "Milestone"
    table.cell(0, 1).text = "Target Date"
    table.cell(1, 0).text = "AML/KYC documentation complete"
    table.cell(1, 1).text = "2026-02"
    table.cell(2, 0).text = "Binance VASP application submitted"
    table.cell(2, 1).text = "2026 Q2"
    table.cell(3, 0).text = "SBI custody due diligence complete"
    table.cell(3, 1).text = "2026-03"

    prs.save(str(path))
    _set_mtime(path, "2026-01-15T09:30:00")
    print(f"Created {path.relative_to(PROJECT_ROOT)}")


def build_pdf() -> None:
    import pymupdf

    folder = SAMPLE_DIR / "Legal"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "Digital Asset Custody Framework.pdf"

    doc = pymupdf.open()
    page_texts = [
        (
            "Digital Asset Custody Framework\n"
            "Internal Policy Draft -- v0.3\n\n"
            "1. Purpose\n"
            "This document defines minimum control requirements for any "
            "third-party or in-house custody solution used to hold digital "
            "assets on behalf of clients or the firm."
        ),
        (
            "2. Segregation and Audit Controls\n\n"
            "Digital asset custody requires segregation controls and "
            "independent audit trails to protect client assets. Client "
            "assets must be held in wallets segregated from firm assets, "
            "with quarterly independent audit confirmation of holdings."
        ),
        (
            "3. Vendor Evaluation\n\n"
            "As part of the custody vendor selection process, the "
            "Steering Committee is evaluating SBI custody alongside two "
            "other qualified custodians. Evaluation criteria include "
            "insurance coverage, key management architecture, and "
            "regulatory standing in relevant jurisdictions.\n\n"
            "A VASP license (or equivalent registration) is a "
            "prerequisite for any custodian handling client digital "
            "assets on the firm's behalf."
        ),
        (
            "4. Stablecoin Reserve Considerations\n\n"
            "Where stablecoins such as USDT are held in custody, the "
            "custodian must provide evidence of reserve backing "
            "disclosures on at least a monthly basis. Any material gap "
            "in reserve transparency should be escalated to Compliance "
            "before further accumulation of that stablecoin."
        ),
    ]
    for text in page_texts:
        page = doc.new_page()
        page.insert_textbox(pymupdf.Rect(56, 56, 540, 780), text, fontsize=11, fontname="helv")

    doc.save(str(path))
    doc.close()
    _set_mtime(path, "2026-02-10T14:00:00")
    print(f"Created {path.relative_to(PROJECT_ROOT)}")


def build_docx() -> None:
    import docx

    folder = SAMPLE_DIR / "Meetings"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "2026-02-20 Steering Committee Notes.docx"

    document = docx.Document()
    document.add_heading("2026-02-20 Web3 Steering Committee -- Meeting Notes", level=1)

    document.add_heading("Attendees", level=2)
    document.add_paragraph("Compliance, Legal, Digital Assets Product, Operations (4 attendees).")

    document.add_heading("Discussion: VASP Application", level=2)
    document.add_paragraph(
        "Management requested the team to assess operating-bank readiness "
        "before Binance's VASP application is submitted. Operations to "
        "confirm banking partner capacity for expected transaction volume."
    )
    document.add_paragraph(
        "法務確認 VASP 申請文件範本已更新，將於下週提交金管會諮詢會議前完成內部審閱。"
    )

    document.add_heading("Discussion: Custody Vendor", level=2)
    document.add_paragraph(
        "Team to finalize evaluation of SBI custody vs. in-house cold "
        "storage before the next committee meeting. SBI custody's technical "
        "presentation is scheduled for early March."
    )

    document.add_heading("Discussion: Stablecoin Exposure", level=2)
    document.add_paragraph(
        "Current USDT exposure remains within approved limits. Compliance "
        "will continue monitoring monthly reserve attestations."
    )

    document.add_heading("Action Items", level=2)
    table = document.add_table(rows=1, cols=3)
    table.style = "Light Grid Accent 1"
    header = table.rows[0].cells
    header[0].text = "Item"
    header[1].text = "Owner"
    header[2].text = "Due"
    rows = [
        ("Confirm operating-bank readiness for VASP application", "Operations", "2026-03-05"),
        ("Schedule SBI custody technical presentation", "Digital Assets Product", "2026-03-01"),
        ("Review monthly USDT reserve attestation", "Compliance", "2026-03-10"),
    ]
    for item, owner, due in rows:
        cells = table.add_row().cells
        cells[0].text = item
        cells[1].text = owner
        cells[2].text = due

    document.save(str(path))
    _set_mtime(path, "2026-02-20T16:45:00")
    print(f"Created {path.relative_to(PROJECT_ROOT)}")


def build_markdown() -> None:
    folder = SAMPLE_DIR / "Research"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "stablecoin-and-rwa-notes.md"

    content = """# Stablecoin & RWA Market Notes

Internal research notes, maintained by the Digital Assets Product team.

## Stablecoins

USDT remains the most widely circulated stablecoin relevant to our
custody and settlement flows. As first flagged in the Web3 Steering
Committee deck (2026-01-15), reserve transparency is the main ongoing
monitoring item -- see the Custody Framework's stablecoin reserve
section for the escalation threshold.

台灣市場對穩定幣的關注持續升高，USDT 的鏈上流通量在過去一季顯著成長。

## RWA Tokenization

Real World Asset (RWA) tokenization continues to gain traction with
institutional players. Potential near-term angle: a tokenized
short-term bond fund, pending confirmation of a licensed custody
partner (see custody vendor evaluation, including SBI custody).

## Regulatory Watch

Binance's Taiwan VASP application is the most time-sensitive item on
our regulatory radar this quarter. Track against the milestone table
in the Steering Committee deck.
"""
    path.write_text(content, encoding="utf-8")
    _set_mtime(path, "2026-03-01T11:00:00")
    print(f"Created {path.relative_to(PROJECT_ROOT)}")


def build_edge_case_files() -> None:
    """A few deliberately awkward files to exercise error handling in QA."""
    folder = SAMPLE_DIR / "edge_cases"
    folder.mkdir(parents=True, exist_ok=True)

    empty_txt = folder / "empty_file.txt"
    empty_txt.write_text("", encoding="utf-8")
    _set_mtime(empty_txt, "2026-01-01T00:00:00")

    corrupt_pdf = folder / "corrupt.pdf"
    corrupt_pdf.write_bytes(b"%PDF-1.4\nThis is not a real PDF stream.\n%%EOF")
    _set_mtime(corrupt_pdf, "2026-01-01T00:00:00")

    unsupported = folder / "notes.csv"
    unsupported.write_text("col1,col2\nnot,indexed\n", encoding="utf-8")
    _set_mtime(unsupported, "2026-01-01T00:00:00")

    print(f"Created edge-case files in {folder.relative_to(PROJECT_ROOT)}")


def main() -> None:
    if SAMPLE_DIR.exists():
        shutil.rmtree(SAMPLE_DIR)
    SAMPLE_DIR.mkdir(parents=True)

    build_pptx()
    build_pdf()
    build_docx()
    build_markdown()
    build_edge_case_files()

    print("\nSample corpus generated at:", SAMPLE_DIR)


if __name__ == "__main__":
    main()
