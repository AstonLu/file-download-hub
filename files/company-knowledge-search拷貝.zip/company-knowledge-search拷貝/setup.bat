@echo off
REM ============================================================
REM  Company Knowledge Search - Setup
REM
REM  Installs the Python packages this application needs.
REM  Run this once (and again any time requirements.txt changes).
REM  No admin rights, Docker, or internet access at RUN time are
REM  required -- only this one-time install step needs internet
REM  access to download the packages.
REM ============================================================

setlocal

REM Always run from the folder this script lives in, so it works
REM correctly no matter where it was double-clicked from.
cd /d "%~dp0"

echo ============================================
echo  Company Knowledge Search - Setup
echo ============================================
echo.

REM Do not assume "py" is guaranteed to exist, but it ships with the
REM standard Windows Python installer and is the recommended launcher.
where py >nul 2>nul
if errorlevel 1 (
    echo ERROR: Could not find the "py" launcher on this computer.
    echo.
    echo Please install Python from https://www.python.org/downloads/
    echo During installation, make sure "py launcher" is included
    echo ^(this is the default^).
    echo.
    pause
    exit /b 1
)

if not exist "requirements.txt" (
    echo ERROR: requirements.txt was not found in this folder:
    echo   %cd%
    echo Make sure you copied the whole company-knowledge-search folder.
    pause
    exit /b 1
)

echo Installing required packages. This may take a few minutes...
echo   py -m pip install -r requirements.txt
echo.
py -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo ERROR: Package installation failed. See the messages above.
    pause
    exit /b 1
)

echo.
echo ============================================
echo  Setup complete.
echo  Next step: run start.bat to launch the app.
echo ============================================
pause
