"""Company Knowledge Search -- Streamlit UI.

A local-first keyword search engine over a folder of project documents
(PDF, PPTX, DOCX, MD, TXT). Every search result links back to its exact
source (file, page/slide, section) so results are always verifiable.

This is v0: reliable keyword search, not an AI chatbot. Nothing in this
application makes a network call -- documents, the search index, and all
processing stay on this machine.
"""

from __future__ import annotations

import html
import logging
import os
import subprocess
import sys
from pathlib import Path

import streamlit as st

from src.config import (
    DEFAULT_CHUNK_OVERLAP,
    DEFAULT_CHUNK_SIZE,
    MAX_CHUNK_SIZE,
    MIN_CHUNK_SIZE,
    AppConfig,
    load_config,
    save_config,
)
from src.database import clear_all, connect, get_stats, initialize_schema
from src.indexing import sync_source_folder
from src.logging_setup import configure_logging
from src.search import SNIPPET_MARK_END, SNIPPET_MARK_START, SearchFilters, list_document_types, search

configure_logging()
logger = logging.getLogger("app")

st.set_page_config(page_title="Company Knowledge Search", page_icon="🔎", layout="wide")

st.markdown(
    """
    <style>
    mark { background-color: #ffe08a; padding: 0 2px; border-radius: 2px; }
    .source-location { color: #667085; font-size: 0.88rem; margin-top: -0.4rem; }
    div[data-testid="stMetricValue"] { font-size: 1.4rem; }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_resource(show_spinner=False)
def get_connection(db_path_str: str):
    conn = connect(Path(db_path_str))
    initialize_schema(conn)
    return conn


def render_snippet_html(snippet: str) -> str:
    """Escape snippet text for safe HTML rendering, then turn our internal
    highlight markers into <mark> tags (see src/search.py)."""
    escaped = html.escape(snippet)
    escaped = escaped.replace(SNIPPET_MARK_START, "<mark>").replace(SNIPPET_MARK_END, "</mark>")
    return escaped.replace("\n", "<br>")


def open_file_in_default_app(absolute_path: Path) -> tuple[bool, str]:
    """Open a file with the OS default application. This runs on the local
    machine only (Streamlit's backend process runs on the user's own
    computer), so it is not a browser action and does not touch any
    browser file:// security restrictions."""
    try:
        if not absolute_path.exists():
            return False, "File not found at this path (it may have moved)."
        if sys.platform.startswith("win"):
            os.startfile(str(absolute_path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.run(["open", str(absolute_path)], check=True)
        else:
            subprocess.run(["xdg-open", str(absolute_path)], check=True)
        return True, ""
    except Exception as exc:  # pragma: no cover -- OS-dependent
        return False, str(exc)


# ---------------------------------------------------------------------------
# Session / config bootstrap
# ---------------------------------------------------------------------------

if "config" not in st.session_state:
    st.session_state.config = load_config()

config: AppConfig = st.session_state.config
conn = get_connection(config.db_path)


def persist_config() -> None:
    save_config(config)


# ---------------------------------------------------------------------------
# Sidebar: source folder, sync, stats, danger zone
# ---------------------------------------------------------------------------

with st.sidebar:
    st.header("Knowledge base settings")

    source_folder_input = st.text_input(
        "Source folder",
        value=config.source_folder,
        placeholder=r"e.g. C:\Users\you\Documents\Project Files",
        help="Full path to the folder containing your project documents. "
        "Sub-folders are scanned automatically.",
    )

    with st.expander("Chunking settings (advanced)"):
        chunk_size_input = st.number_input(
            "Chunk size (characters)",
            min_value=MIN_CHUNK_SIZE,
            max_value=MAX_CHUNK_SIZE,
            value=config.chunk_size,
            step=100,
            help="How much text goes into one searchable chunk. Only affects "
            "documents indexed after this is changed.",
        )
        chunk_overlap_input = st.number_input(
            "Chunk overlap (characters)",
            min_value=0,
            max_value=int(chunk_size_input) - 1,
            value=min(config.chunk_overlap, int(chunk_size_input) - 1),
            step=50,
        )

    if (
        source_folder_input != config.source_folder
        or int(chunk_size_input) != config.chunk_size
        or int(chunk_overlap_input) != config.chunk_overlap
    ):
        config.source_folder = source_folder_input
        config.chunk_size = int(chunk_size_input)
        config.chunk_overlap = int(chunk_overlap_input)
        persist_config()

    st.caption(f"Database location:  \n`{config.db_path}`")

    sync_clicked = st.button("🔄 Sync knowledge base", type="primary", use_container_width=True)

    if sync_clicked:
        if not config.source_folder.strip():
            st.error("Enter a source folder first.")
        elif not Path(config.source_folder).exists():
            st.error(f"Folder not found: {config.source_folder}")
        else:
            with st.spinner("Syncing... large folders can take a while the first time."):
                report = sync_source_folder(
                    conn, Path(config.source_folder), config.chunk_size, config.chunk_overlap
                )
            st.session_state.last_sync_report = report

    if "last_sync_report" in st.session_state:
        r = st.session_state.last_sync_report
        st.success("Sync completed")
        st.text(
            f"New:       {r.new}\n"
            f"Updated:   {r.updated}\n"
            f"Deleted:   {r.deleted}\n"
            f"Unchanged: {r.unchanged}\n"
            f"Failed:    {r.failed}"
        )
        if r.warnings:
            with st.expander(f"⚠️ {len(r.warnings)} document(s) indexed with warnings"):
                for path, msg in r.warnings:
                    st.markdown(f"**{path}**  \n{msg}")
        if r.failures:
            with st.expander(f"❌ {len(r.failures)} document(s) failed"):
                for path, msg in r.failures:
                    st.markdown(f"**{path}**  \n{msg}")

    st.divider()
    stats = get_stats(conn)
    stat_col1, stat_col2 = st.columns(2)
    stat_col1.metric("Documents", stats["document_count"])
    stat_col2.metric("Chunks", stats["chunk_count"])
    if stats["failed_count"]:
        st.caption(f"⚠️ {stats['failed_count']} document(s) failed to index")
    if stats["warning_count"]:
        st.caption(f"⚠️ {stats['warning_count']} document(s) indexed with warnings")

    st.divider()
    with st.expander("Danger zone"):
        st.warning(
            "Clearing the index deletes all indexed documents and chunks from "
            "the local database. Files in your source folder are never "
            "touched. You can rebuild the index by syncing again."
        )
        confirm_clear = st.checkbox("I understand, clear the index")
        if st.button("Clear index", disabled=not confirm_clear):
            clear_all(conn)
            st.session_state.pop("last_sync_report", None)
            logger.info("Index cleared by user.")
            st.success("Index cleared.")
            st.rerun()


# ---------------------------------------------------------------------------
# Main area: search
# ---------------------------------------------------------------------------

st.title("Company Knowledge Search")
st.caption(
    "Local keyword search across your project documents. This is keyword "
    "search, not AI/semantic search -- every result shows exactly where it "
    "came from."
)

search_col, sort_col = st.columns([4, 1])
with search_col:
    query = st.text_input(
        "Search",
        placeholder='Search your documents... e.g. Binance, VASP, "SBI custody"',
        label_visibility="collapsed",
    )
with sort_col:
    sort_order = st.selectbox(
        "Sort by",
        ["Relevance", "Oldest first", "Newest first"],
        label_visibility="collapsed",
        help="Useful for questions like 'when was this first mentioned?'",
    )

with st.expander("Filters"):
    filter_col1, filter_col2, filter_col3 = st.columns(3)
    with filter_col1:
        available_types = ["All"] + list_document_types(conn)
        type_filter = st.selectbox("File type", available_types)
    with filter_col2:
        filename_filter = st.text_input("Filename contains")
    with filter_col3:
        path_filter = st.text_input("Path / subfolder contains")

    date_col1, date_col2 = st.columns(2)
    with date_col1:
        date_after = st.date_input("Modified after", value=None, format="YYYY-MM-DD")
    with date_col2:
        date_before = st.date_input("Modified before", value=None, format="YYYY-MM-DD")

if stats["document_count"] == 0:
    st.info(
        "No documents indexed yet. Enter a source folder in the sidebar and "
        "click **Sync knowledge base** to get started."
    )
elif query.strip():
    filters = SearchFilters(
        document_type=None if type_filter == "All" else type_filter,
        filename_contains=filename_filter.strip() or None,
        path_contains=path_filter.strip() or None,
        modified_after=date_after.isoformat() if date_after else None,
        modified_before=f"{date_before.isoformat()}T23:59:59" if date_before else None,
    )
    results = search(conn, query, filters=filters, limit=50)

    if sort_order == "Oldest first":
        results.sort(key=lambda r: r.file_modified_at or "")
    elif sort_order == "Newest first":
        results.sort(key=lambda r: r.file_modified_at or "", reverse=True)

    st.caption(f'{len(results)} result(s) for "{query}"')

    if not results:
        st.info("No matches. Try a different or shorter search term.")

    source_root = Path(config.source_folder) if config.source_folder else None

    for result in results:
        with st.container(border=True):
            location_bits = [result.relative_path]
            if result.page_number is not None:
                location_bits.append(f"Page {result.page_number}")
            if result.slide_number is not None:
                location_bits.append(f"Slide {result.slide_number}")
            if result.section:
                location_bits.append(result.section)

            st.markdown(f"**{result.source_file}**")
            st.markdown(f'<div class="source-location">{html.escape(" · ".join(location_bits))}</div>', unsafe_allow_html=True)
            st.markdown(render_snippet_html(result.snippet), unsafe_allow_html=True)

            with st.expander("Source details"):
                detail_col1, detail_col2 = st.columns([3, 1])
                with detail_col1:
                    st.text(
                        f"Document type: {result.document_type}\n"
                        f"Modified:      {result.file_modified_at or 'unknown'}\n"
                        f"Indexed:       {result.indexed_at}"
                    )
                    st.code(result.relative_path, language=None)
                with detail_col2:
                    if source_root is not None and st.button("Open file", key=f"open_{result.chunk_id}"):
                        ok, err = open_file_in_default_app(source_root / result.relative_path)
                        if ok:
                            st.toast(f"Opened {result.source_file}")
                        else:
                            st.error(f"Could not open file: {err}")
                st.text_area("Full chunk text", result.text, height=120, key=f"text_{result.chunk_id}")
else:
    st.info('Enter a search term above. Try: "Binance", "VASP", "custody", "USDT", "stablecoin".')
