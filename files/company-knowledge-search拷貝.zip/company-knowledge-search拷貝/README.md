# Company Knowledge Search

A local, private search engine for your team's project documents. Point it
at a folder, click **Sync**, and search across every PDF, PowerPoint, Word,
and text file inside it -- from a simple page in your web browser.

Every result tells you exactly which file, page, or slide it came from, so
you can always go verify the source yourself.

> **This is keyword search, not an AI chatbot.** It finds documents that
> contain the words you searched for -- it does not summarize, answer
> questions in sentences, or "understand" meaning. See [Known
> limitations](#known-limitations) below.

---

## What this application does

1. You tell it which folder on your computer holds your project documents
   (it looks inside all sub-folders too).
2. You click **Sync Knowledge Base**. It reads every PDF, PowerPoint,
   Word, Markdown, and text file it finds, and builds a private search
   index -- a bit like building an index at the back of a book, except
   for an entire folder of documents.
3. You type a search term (in English, Chinese, or both) into the search
   box. It shows you every place that term appears, with the exact file
   name, page or slide number, and a preview of the matching text.

Everything happens on your own computer. Nothing is uploaded anywhere.

---

## Architecture

```text
Project Source Folder
        |
        v
   File Scanner  ---------------->  Change Detection
        |                           (new / modified / deleted,
        |                            via SHA-256 content hash)
        v
   Document Parsers
   PDF / PPTX / DOCX / MD / TXT
        |
        v
  Normalized Text + Source Metadata
        |
        v
   Chunking (deterministic, page/slide-aware)
        |
        v
      SQLite
      +-- documents  (one row per file, with status)
      +-- chunks     (searchable text + full provenance)
      +-- chunks_fts (FTS5 full-text search index)
        |
        v
   Search Service (keyword search, ranked results)
        |
        v
   Streamlit web UI  -->  results with file / page / slide citations
```

Nothing here requires Docker, Node.js, a cloud database, or an internet
connection to run. It is one Python application, one local SQLite file,
and a browser tab.

---

## Supported files

| Format | Extension | What is tracked as the "location" |
|---|---|---|
| PDF | `.pdf` | Page number |
| PowerPoint | `.pptx` | Slide number, slide title |
| Word | `.docx` | Section / heading (Word does not expose reliable page numbers -- see [Known limitations](#known-limitations)) |
| Markdown | `.md` | Paragraph position |
| Plain text | `.txt` | Paragraph position |

---

## Installation on Windows

**Requirements already on your machine (per your IT setup):** Windows,
Python 3.14, pip, and the packages `pymupdf`, `python-pptx`, `python-docx`,
and `streamlit`.

1. Copy the whole `company-knowledge-search` folder to your computer
   (e.g. onto your Desktop or into `Documents`).
2. Double-click **`setup.bat`**.
   - This runs `py -m pip install -r requirements.txt`, which installs
     the packages listed above (they may already be present, in which
     case this is quick) plus `pytest` for running the automated tests.
   - A window will open showing progress; wait for it to say
     "Setup complete", then press any key to close it.

If `setup.bat` reports it cannot find the `py` launcher, install Python
from [python.org](https://www.python.org/downloads/) first (the standard
installer includes it automatically), then run `setup.bat` again.

No administrator rights are required.

---

## Starting the application

Double-click **`start.bat`**.

- A console window opens and starts the application.
- Your default web browser should open automatically to
  `http://localhost:8501`. If it does not open by itself, open that
  address manually in any browser.
- Everything is served from your own computer (`localhost`); nothing is
  reachable from the internet or from other computers on your network.
- To stop the application, close the console window, or click inside it
  and press `Ctrl+C`.

---

## Adding project documents

In the left-hand sidebar, enter the **Source Folder** -- the full path to
the folder containing your project's documents, for example:

```text
C:\Users\yourname\Documents\Project Files
```

This is saved automatically (in `data/config.json` on your own computer),
so you only need to type it once. Sub-folders are included automatically;
organize your documents into folders however makes sense for your team --
that folder structure is preserved and searchable ("Path / subfolder
contains" filter).

---

## Sync behavior

Click **Sync Knowledge Base** in the sidebar whenever you want the search
index to catch up with changes in your source folder. A sync:

- Reads every supported file in the folder and its sub-folders.
- Compares each file against what was indexed last time, using a content
  fingerprint (SHA-256 hash) plus file size and modified date as a fast
  first check.
- **Only processes what actually changed.** Unchanged files are skipped
  entirely -- a repeat sync over a large, mostly-unchanged folder is fast.
- Reports a summary:

  ```text
  New:       3
  Updated:   2
  Deleted:   1
  Unchanged: 184
  Failed:    0
  ```

- If a file cannot be read (corrupted, password-protected, temporarily
  locked, etc.), that one file is skipped and reported under "Failed" or
  "warnings" -- it does not stop the rest of the sync.
- If a file is removed from the source folder, its entries disappear from
  the search index on the next sync.

---

## Search

Type into the search box at the top of the main page. A few tips:

- Multiple words (`Binance VASP`) finds chunks containing **all** of those
  words.
- Quotation marks (`"SBI custody"`) search for that **exact phrase**.
- Chinese, English, and mixed Chinese/English queries are all supported,
  including short two-character Chinese terms (e.g. `申請`, `台灣`).
- Use the **Filters** panel to narrow by file type, filename, path/folder,
  or modified date.
- Use **Sort by** (top right of the search box) to switch between
  relevance and oldest/newest first -- useful for "when was this first
  mentioned?" style questions.

This is **keyword search**: it finds text that actually contains your
search term (or, for short Chinese terms, that exact character sequence).
It does not understand synonyms, related concepts, or natural-language
questions the way an AI assistant would.

---

## Source citations

Every result shows, without you needing to ask:

- The original file name and its path within your source folder
- Document type (PDF / PPTX / DOCX / MD / TXT)
- Page number (PDF) or slide number and slide title (PPTX)
- Section/heading context (DOCX, where available)
- The document's last-modified date, and when it was indexed
- The exact matching text, highlighted

Click **Source details** on any result to see the full chunk text, the
relative path (for copying), and an **Open file** button that opens the
original document in its default application directly from your computer
(this only works if the source folder is still at the path configured in
the sidebar).

---

## Data privacy

- All processing happens on your computer. No document content, file
  names, or search queries are sent anywhere.
- The search index is a single SQLite file at `data/knowledge.db` on your
  own machine.
- There is no telemetry, no analytics, and no third-party service of any
  kind involved in running this application.
- This repository ships only synthetic, invented sample documents (see
  `sample_source/`) -- never commit real company documents into this
  folder or its Git history.

---

## Known limitations

- **Scanned/image-only PDFs are not searchable yet.** This version does
  not perform OCR. If a PDF has no extractable text layer, the sync
  report will flag it with a warning rather than silently skipping it.
- **Word documents do not have reliable page numbers.** Microsoft Word
  computes page breaks at print/render time, not from the file itself, so
  `python-docx` cannot report them accurately. Results from `.docx` files
  are located by section/heading instead of by page.
- **This is keyword search, not semantic search.** A search for "digital
  currency" will not automatically find a passage that only says
  "stablecoin" -- you need to search for the actual words used.
- **Diagrams, charts, and images inside documents are not read.** Only
  extractable text is indexed.
- **Very short non-Latin query terms use a slower search path.** Chinese
  search terms under 3 characters (e.g. a single character) fall back to
  a full-text scan instead of the indexed search, which stays fast at the
  document volumes this tool targets (hundreds to a few thousand files)
  but is not as fast as indexed search on much larger corpora.

---

## Future roadmap: toward hybrid RAG search

This version is deliberately just the retrieval foundation. It is built
so a future version can add semantic search and an AI-generated answer
layer without changing how documents are indexed or cited:

```text
Query
  |
  +--> FTS keyword retrieval (this version)
  |
  +--> Vector/semantic retrieval (future)
  |
  v
Hybrid ranking
  |
  v
Top-K evidence (with the same source citations this version already produces)
  |
  v
Corporate private LLM API (future)
  |
  v
Answer + citations
```

Planned next steps, in order:

1. **Hybrid search** -- add a vector index alongside the existing FTS5
   index and combine both rankings, so semantically related passages are
   found even when the exact wording differs.
2. **Embeddings** -- generate embeddings locally or via a corporate
   embedding API, without sending raw document text to a public API.
3. **Corporate LLM RAG layer** -- feed top-ranked, cited chunks into an
   internal/private LLM API to generate a direct answer with citations
   back to this same source-metadata model, rather than requiring the
   user to read through each result manually.

None of these require changing the database schema, the parsers, or the
citation model already in place -- they are additive layers on top of
this retrieval foundation.
