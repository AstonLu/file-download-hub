@echo off
REM ============================================================
REM  Company Knowledge Search - Start
REM
REM  Launches the local web application. A browser tab should
REM  open automatically at http://localhost:8501
REM
REM  Everything runs on this computer only -- no internet access
REM  is used, and no document content leaves this machine.
REM
REM  To stop the application: close this window, or click inside
REM  it and press CTRL+C.
REM ============================================================

setlocal

cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
    echo ERROR: Could not find the "py" launcher on this computer.
    echo Please run setup.bat first, or install Python from
    echo https://www.python.org/downloads/
    pause
    exit /b 1
)

if not exist "app.py" (
    echo ERROR: app.py was not found in this folder:
    echo   %cd%
    echo Make sure you copied the whole company-knowledge-search folder.
    pause
    exit /b 1
)

echo Starting Company Knowledge Search...
echo A browser tab should open automatically. If it does not,
echo open this address manually: http://localhost:8501
echo.
echo Close this window (or press CTRL+C) to stop the application.
echo.

py -m streamlit run app.py

pause
