"""Application-wide logging configuration.

Logs go to ``logs/app.log`` (rotated at 2 MB, 3 backups kept). Only
operational events are logged (start/stop, sync progress, parser
failures, database errors) -- document contents are never written to the
log file.
"""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler

from src.config import LOG_PATH

_configured = False


def configure_logging() -> None:
    """Attach a rotating file handler to the root logger, once per process."""
    global _configured
    if _configured:
        return

    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(LOG_PATH, maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(handler)

    _configured = True
    logging.getLogger("app").info("Application started.")
