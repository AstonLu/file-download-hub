"""PDF parsing using PyMuPDF, with page-level provenance.

OCR is explicitly out of scope for v0: a PDF with no extractable text (e.g.
a scanned image) is surfaced as a warning rather than silently producing
zero chunks.
"""

from __future__ import annotations

from pathlib import Path

from src.models import ExtractedUnit, ParseResult
from src.parsers.base import DocumentParser


class PdfParser(DocumentParser):
    """Extracts one ExtractedUnit per page, using 1-based page numbers."""

    def parse(self, file_path: Path) -> ParseResult:
        try:
            import pymupdf
        except ImportError as exc:
            return ParseResult(status="failed", message=f"PyMuPDF is not installed: {exc}")

        try:
            document = pymupdf.open(str(file_path))
        except Exception as exc:
            return ParseResult(status="failed", message=f"Could not open PDF: {exc}")

        try:
            return self._parse_document(document)
        finally:
            document.close()

    def _parse_document(self, document) -> ParseResult:
        if document.is_encrypted:
            # Some PDFs are flagged encrypted but openable with an empty
            # password; only report failure if that does not work.
            if not document.authenticate(""):
                return ParseResult(
                    status="failed",
                    message="PDF is password-protected and could not be opened.",
                )

        page_count = document.page_count
        if page_count == 0:
            return ParseResult(units=[], status="warning", message="PDF has no pages.")

        units: list[ExtractedUnit] = []
        pages_with_text = 0
        page_errors = 0

        for page_index in range(page_count):
            page_number = page_index + 1
            try:
                page = document.load_page(page_index)
                text = (page.get_text("text") or "").strip()
            except Exception:
                page_errors += 1
                units.append(ExtractedUnit(text="", page_number=page_number))
                continue

            if text:
                pages_with_text += 1
            units.append(ExtractedUnit(text=text, page_number=page_number))

        if pages_with_text == 0:
            return ParseResult(
                units=units,
                status="warning",
                message=(
                    f"No extractable text found in {page_count} page(s). "
                    "This may be a scanned/image-only PDF; OCR is not "
                    "supported in this version."
                ),
            )

        if page_errors > 0:
            return ParseResult(
                units=units,
                status="warning",
                message=f"{page_errors} of {page_count} page(s) could not be read and were skipped.",
            )

        return ParseResult(units=units, status="ok")
