"""Common interface that every document parser must implement."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from src.models import ParseResult

# Bumped whenever parsing logic changes in a way that would change output
# for already-indexed documents. Stored per-document so a future version
# could use it to decide whether to force a re-parse.
PARSER_VERSION = "1"


class DocumentParser(ABC):
    """Extracts normalized text units (with source provenance) from a file."""

    @abstractmethod
    def parse(self, file_path: Path) -> ParseResult:
        """Parse a document and return its extracted units.

        Implementations must never raise for expected failure modes (a
        corrupt file, an encrypted file, an empty file, a page that fails to
        extract); those are reported via ``ParseResult.status`` /
        ``ParseResult.message`` instead, so that one bad file cannot crash a
        whole sync.
        """
        raise NotImplementedError
