"""PPTX parsing using python-pptx, with slide-level provenance.

Each slide becomes its own ExtractedUnit (with the slide's title carried as
``section``), so a 100-slide deck is never flattened into one giant string
and slide provenance survives chunking.
"""

from __future__ import annotations

from pathlib import Path

from src.models import ExtractedUnit, ParseResult
from src.parsers.base import DocumentParser


class PptxParser(DocumentParser):
    """Extracts one ExtractedUnit per slide, using 1-based slide numbers."""

    def parse(self, file_path: Path) -> ParseResult:
        try:
            from pptx import Presentation
        except ImportError as exc:
            return ParseResult(status="failed", message=f"python-pptx is not installed: {exc}")

        try:
            presentation = Presentation(str(file_path))
        except Exception as exc:
            return ParseResult(status="failed", message=f"Could not open PPTX: {exc}")

        slides = list(presentation.slides)
        if not slides:
            return ParseResult(units=[], status="warning", message="Presentation has no slides.")

        units: list[ExtractedUnit] = []
        slides_with_text = 0
        slide_errors = 0

        for slide_index, slide in enumerate(slides, start=1):
            try:
                title, lines = _extract_slide_text(slide)
                text = "\n".join(lines).strip()
            except Exception:
                slide_errors += 1
                units.append(ExtractedUnit(text="", slide_number=slide_index))
                continue

            if text:
                slides_with_text += 1
            units.append(ExtractedUnit(text=text, slide_number=slide_index, section=title))

        if slides_with_text == 0:
            return ParseResult(
                units=units,
                status="warning",
                message="No extractable text found in any slide.",
            )

        if slide_errors > 0:
            return ParseResult(
                units=units,
                status="warning",
                message=f"{slide_errors} of {len(slides)} slide(s) could not be read and were skipped.",
            )

        return ParseResult(units=units, status="ok")


def _extract_slide_text(slide) -> tuple[str | None, list[str]]:
    """Return (slide_title, text_lines) for one slide, including table cells and notes."""
    title: str | None = None
    try:
        if slide.shapes.title is not None and slide.shapes.title.has_text_frame:
            title_text = slide.shapes.title.text_frame.text.strip()
            title = title_text or None
    except Exception:
        title = None

    lines: list[str] = []
    for shape in slide.shapes:
        try:
            lines.extend(_shape_text_lines(shape))
        except Exception:
            continue

    try:
        if slide.has_notes_slide:
            notes = slide.notes_slide.notes_text_frame.text.strip()
            if notes:
                lines.append(f"[Speaker notes] {notes}")
    except Exception:
        pass

    return title, lines


def _shape_text_lines(shape) -> list[str]:
    """Recursively extract text lines from a shape: text boxes, tables, and groups."""
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    lines: list[str] = []

    if getattr(shape, "has_text_frame", False):
        for paragraph in shape.text_frame.paragraphs:
            line = paragraph.text.strip()
            if line:
                lines.append(line)

    if getattr(shape, "has_table", False):
        for row in shape.table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            if any(cells):
                lines.append(" | ".join(cells))

    if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
        for sub_shape in shape.shapes:
            lines.extend(_shape_text_lines(sub_shape))

    return lines
