"""DOCX parsing using python-docx.

python-docx does not expose reliable page numbers (Word computes pagination
at render/print time, not from the document XML), so this parser tracks
heading/section context instead of fabricating page numbers. Paragraphs are
grouped under the most recent heading seen, which becomes the chunk
``section`` field.
"""

from __future__ import annotations

from pathlib import Path

from src.models import ExtractedUnit, ParseResult
from src.parsers.base import DocumentParser

HEADING_STYLE_PREFIX = "Heading"
TITLE_STYLE_NAME = "Title"


class DocxParser(DocumentParser):
    """Extracts one ExtractedUnit per non-empty paragraph and table row."""

    def parse(self, file_path: Path) -> ParseResult:
        try:
            import docx
        except ImportError as exc:
            return ParseResult(status="failed", message=f"python-docx is not installed: {exc}")

        try:
            document = docx.Document(str(file_path))
        except Exception as exc:
            return ParseResult(status="failed", message=f"Could not open DOCX: {exc}")

        units: list[ExtractedUnit] = []
        current_section: str | None = None
        has_text = False
        partial_error: str | None = None

        try:
            for paragraph in document.paragraphs:
                text = paragraph.text.strip()
                style_name = _safe_style_name(paragraph)
                if text and (style_name.startswith(HEADING_STYLE_PREFIX) or style_name == TITLE_STYLE_NAME):
                    current_section = text
                if text:
                    has_text = True
                    units.append(ExtractedUnit(text=text, section=current_section))

            for table_index, table in enumerate(document.tables, start=1):
                table_section = current_section or f"Table {table_index}"
                for row in table.rows:
                    cells = [cell.text.strip() for cell in row.cells]
                    if any(cells):
                        has_text = True
                        units.append(ExtractedUnit(text=" | ".join(cells), section=table_section))
        except Exception as exc:
            partial_error = str(exc)

        if partial_error:
            return ParseResult(
                units=units,
                status="warning",
                message=f"Extraction stopped early due to an error: {partial_error}",
            )

        if not has_text:
            return ParseResult(units=units, status="warning", message="No extractable text found in document.")

        return ParseResult(units=units, status="ok")


def _safe_style_name(paragraph) -> str:
    try:
        style = paragraph.style
        return style.name or "" if style is not None else ""
    except Exception:
        return ""
