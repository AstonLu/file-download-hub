"""Plain text and Markdown parsing.

Files are read as UTF-8. If a file contains bytes that are not valid UTF-8
(e.g. a legacy Windows encoding), decoding falls back to replacing invalid
bytes rather than raising, so one malformed file cannot abort a sync.
"""

from __future__ import annotations

from pathlib import Path

from src.models import ExtractedUnit, ParseResult
from src.parsers.base import DocumentParser


class TextParser(DocumentParser):
    """Extracts one ExtractedUnit per blank-line-delimited paragraph."""

    def parse(self, file_path: Path) -> ParseResult:
        try:
            raw_bytes = file_path.read_bytes()
        except OSError as exc:
            return ParseResult(status="failed", message=f"Could not read file: {exc}")

        if not raw_bytes:
            return ParseResult(units=[], status="warning", message="File is empty.")

        try:
            text = raw_bytes.decode("utf-8")
            had_decode_errors = False
        except UnicodeDecodeError:
            text = raw_bytes.decode("utf-8", errors="replace")
            had_decode_errors = True

        text = text.strip()
        if not text:
            return ParseResult(units=[], status="warning", message="File is empty.")

        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
        if not paragraphs:
            paragraphs = [text]

        units = [ExtractedUnit(text=paragraph) for paragraph in paragraphs]

        if had_decode_errors:
            return ParseResult(
                units=units,
                status="warning",
                message="File is not valid UTF-8; some characters may have been replaced.",
            )

        return ParseResult(units=units, status="ok")
