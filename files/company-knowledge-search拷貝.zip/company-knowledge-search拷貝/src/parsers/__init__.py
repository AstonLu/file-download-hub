"""Parser registry: maps file extensions to parser implementations.

Adding support for a new file type means writing a new ``DocumentParser``
subclass and registering it here -- nothing else in the pipeline needs to
change.
"""

from __future__ import annotations

from src.parsers.base import DocumentParser
from src.parsers.docx import DocxParser
from src.parsers.pdf import PdfParser
from src.parsers.pptx import PptxParser
from src.parsers.text import TextParser

_PARSERS: dict[str, DocumentParser] = {
    ".pdf": PdfParser(),
    ".pptx": PptxParser(),
    ".docx": DocxParser(),
    ".md": TextParser(),
    ".txt": TextParser(),
}


def get_parser(extension: str) -> DocumentParser | None:
    """Return the parser registered for a file extension (e.g. ``.pdf``)."""
    return _PARSERS.get(extension.lower())


def supported_extensions() -> set[str]:
    """Return the set of file extensions that have a registered parser."""
    return set(_PARSERS.keys())
