"""Deterministic, provenance-preserving text chunking.

Each ``ExtractedUnit`` (a PDF page, PPTX slide, or Word/text paragraph
group) is chunked independently: chunks never mix text across units, so
every chunk keeps a single, unambiguous page/slide/section reference. This
is plain sliding-window chunking on purpose -- v0 intentionally does not
attempt semantic chunking.
"""

from __future__ import annotations

from src.models import Chunk, ExtractedUnit


def chunk_units(units: list[ExtractedUnit], chunk_size: int, chunk_overlap: int) -> list[Chunk]:
    """Chunk a list of extracted units into fixed-size, overlapping chunks.

    Args:
        units: Extracted units in document order (e.g. one per page/slide).
        chunk_size: Maximum number of characters per chunk.
        chunk_overlap: Number of characters of overlap between consecutive
            chunks within the same unit.

    Returns:
        Chunks in document order, with ``chunk_index`` numbered
        sequentially across the whole document (not reset per unit) so a
        chunk's position in the document is always recoverable.
    """
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    if chunk_overlap < 0 or chunk_overlap >= chunk_size:
        raise ValueError("chunk_overlap must be >= 0 and less than chunk_size")

    chunks: list[Chunk] = []
    chunk_index = 0
    for unit in units:
        text = unit.text.strip()
        if not text:
            continue
        for piece in _split_text(text, chunk_size, chunk_overlap):
            chunks.append(
                Chunk(
                    text=piece,
                    chunk_index=chunk_index,
                    page_number=unit.page_number,
                    slide_number=unit.slide_number,
                    section=unit.section,
                )
            )
            chunk_index += 1
    return chunks


def _split_text(text: str, chunk_size: int, chunk_overlap: int) -> list[str]:
    """Split text into overlapping windows, preferring to break on whitespace."""
    if len(text) <= chunk_size:
        return [text]

    pieces: list[str] = []
    start = 0
    text_len = len(text)

    while start < text_len:
        end = min(start + chunk_size, text_len)
        if end < text_len:
            # Prefer breaking on whitespace so English words are not cut in
            # half. This has no effect on CJK text, which has no spaces --
            # character-level breaks there are expected and fine.
            break_point = text.rfind(" ", start, end)
            if break_point != -1 and break_point > start:
                end = break_point

        piece = text[start:end].strip()
        if piece:
            pieces.append(piece)

        if end >= text_len:
            break

        next_start = end - chunk_overlap
        start = next_start if next_start > start else end

    return pieces
