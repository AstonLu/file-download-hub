"""Sync orchestration: scan the source folder, run parsers, chunk, and write
results to SQLite inside per-document transactions.

Every document is indexed independently: a parser crash, a corrupt file, or
a chunking error for one document is caught, logged, and recorded on that
document's registry row -- it never aborts the rest of the sync, and it
never leaves partial chunk rows behind (the whole write for one document
happens inside a single transaction).
"""

from __future__ import annotations

import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from src.chunking import chunk_units
from src.database import transaction
from src.models import Chunk, DocumentMeta, ParseResult, SyncReport
from src.parsers import get_parser, supported_extensions
from src.parsers.base import PARSER_VERSION
from src.scanner import scan_source_folder

logger = logging.getLogger(__name__)


def sync_source_folder(
    conn: sqlite3.Connection,
    source_folder: Path,
    chunk_size: int,
    chunk_overlap: int,
) -> SyncReport:
    """Run a full incremental sync of the source folder into the database."""
    report = SyncReport()

    if not source_folder.exists() or not source_folder.is_dir():
        report.failed += 1
        report.failures.append((str(source_folder), "Source folder does not exist or is not a directory."))
        logger.error("Source folder does not exist: %s", source_folder)
        return report

    logger.info("Sync started: source_folder=%s", source_folder)
    plan = scan_source_folder(source_folder, supported_extensions(), conn)
    report.unchanged = len(plan.unchanged)

    for relative_path, reason in plan.skipped:
        report.failed += 1
        report.failures.append((relative_path, reason))
        logger.warning("Skipped %s: %s", relative_path, reason)

    for relative_path in plan.to_delete:
        with transaction(conn):
            conn.execute("DELETE FROM documents WHERE relative_path = ?", (relative_path,))
        report.deleted += 1
        logger.info("Deleted from index: %s", relative_path)

    for doc_meta in plan.to_index:
        is_update = _document_exists(conn, doc_meta.relative_path)
        try:
            parse_result = _index_single_document(conn, doc_meta, chunk_size, chunk_overlap)
        except Exception as exc:
            # A database-level failure (e.g. disk full, locked file). Must
            # still not abort the rest of the sync.
            report.failed += 1
            report.failures.append((doc_meta.relative_path, str(exc)))
            logger.exception("Database error while indexing %s", doc_meta.relative_path)
            continue

        if parse_result.status == "failed":
            report.failed += 1
            report.failures.append((doc_meta.relative_path, parse_result.message or "Unknown parsing failure."))
            logger.warning("Failed to parse %s: %s", doc_meta.relative_path, parse_result.message)
            continue

        if parse_result.status == "warning":
            report.warnings.append((doc_meta.relative_path, parse_result.message or "Indexed with warnings."))
            logger.warning("Indexed with warning %s: %s", doc_meta.relative_path, parse_result.message)

        if is_update:
            report.updated += 1
            logger.info("Re-indexed: %s", doc_meta.relative_path)
        else:
            report.new += 1
            logger.info("Indexed: %s", doc_meta.relative_path)

    logger.info(
        "Sync finished: new=%d updated=%d deleted=%d unchanged=%d failed=%d",
        report.new,
        report.updated,
        report.deleted,
        report.unchanged,
        report.failed,
    )
    return report


def _document_exists(conn: sqlite3.Connection, relative_path: str) -> bool:
    row = conn.execute("SELECT 1 FROM documents WHERE relative_path = ?", (relative_path,)).fetchone()
    return row is not None


def _index_single_document(
    conn: sqlite3.Connection,
    doc_meta: DocumentMeta,
    chunk_size: int,
    chunk_overlap: int,
) -> ParseResult:
    """Parse, chunk, and write one document. Always writes a registry row,
    even on failure, so failed documents remain visible in the UI."""
    parser = get_parser(doc_meta.extension)
    if parser is None:
        parse_result = ParseResult(status="failed", message=f"No parser registered for '{doc_meta.extension}'.")
    else:
        try:
            parse_result = parser.parse(Path(doc_meta.absolute_path))
        except Exception as exc:  # parsers should not raise, but never trust that fully
            parse_result = ParseResult(status="failed", message=f"Unexpected parser error: {exc}")

    chunks: list[Chunk] = []
    if parse_result.status != "failed":
        try:
            chunks = chunk_units(parse_result.units, chunk_size, chunk_overlap)
        except Exception as exc:
            parse_result = ParseResult(status="failed", message=f"Chunking failed: {exc}")

    indexed_at = datetime.now(timezone.utc).isoformat()
    document_type = doc_meta.extension.lstrip(".")

    with transaction(conn):
        conn.execute("DELETE FROM documents WHERE relative_path = ?", (doc_meta.relative_path,))
        cursor = conn.execute(
            """
            INSERT INTO documents (
                absolute_path, relative_path, filename, extension, file_size,
                file_modified_at, content_hash, indexed_at, parser_version,
                extraction_status, status_message
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                doc_meta.absolute_path,
                doc_meta.relative_path,
                doc_meta.filename,
                doc_meta.extension,
                doc_meta.file_size,
                doc_meta.file_modified_at,
                doc_meta.content_hash,
                indexed_at,
                PARSER_VERSION,
                parse_result.status,
                parse_result.message,
            ),
        )
        document_id = cursor.lastrowid

        for chunk in chunks:
            conn.execute(
                """
                INSERT INTO chunks (
                    document_id, chunk_index, text, source_file, relative_path,
                    document_type, page_number, slide_number, section,
                    file_modified_at, indexed_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    document_id,
                    chunk.chunk_index,
                    chunk.text,
                    doc_meta.filename,
                    doc_meta.relative_path,
                    document_type,
                    chunk.page_number,
                    chunk.slide_number,
                    chunk.section,
                    doc_meta.file_modified_at,
                    indexed_at,
                ),
            )

    return parse_result
