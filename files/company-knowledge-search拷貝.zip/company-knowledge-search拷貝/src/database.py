"""SQLite database layer: connection management and schema definition.

Search is powered by an FTS5 virtual table using the built-in ``trigram``
tokenizer. Unlike the default ``unicode61`` tokenizer, trigram indexing does
not depend on whitespace to find word boundaries, which makes it reliable
for Chinese/English mixed text where words are not space-separated (see
``src/search.py`` for how short (<3 character) query terms -- which cannot
form a trigram -- are handled with a LIKE fallback).

The ``chunks_fts`` table is kept in sync with ``chunks`` via triggers, and a
foreign key ``ON DELETE CASCADE`` from ``chunks`` to ``documents`` ensures
that deleting a document row removes its chunks (and, through the triggers,
its search index entries) automatically and atomically.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

SCHEMA_VERSION = 1

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    absolute_path TEXT NOT NULL,
    relative_path TEXT NOT NULL UNIQUE,
    filename TEXT NOT NULL,
    extension TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    file_modified_at TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    indexed_at TEXT NOT NULL,
    parser_version TEXT NOT NULL,
    extraction_status TEXT NOT NULL,
    status_message TEXT
);

CREATE TABLE IF NOT EXISTS chunks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    chunk_index INTEGER NOT NULL,
    text TEXT NOT NULL,
    source_file TEXT NOT NULL,
    relative_path TEXT NOT NULL,
    document_type TEXT NOT NULL,
    page_number INTEGER,
    slide_number INTEGER,
    section TEXT,
    file_modified_at TEXT,
    indexed_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_chunks_document_id ON chunks(document_id);
CREATE INDEX IF NOT EXISTS idx_documents_relative_path ON documents(relative_path);

CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
    text,
    content='chunks',
    content_rowid='id',
    tokenize='trigram'
);

CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
    INSERT INTO chunks_fts(rowid, text) VALUES (new.id, new.text);
END;

CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
    INSERT INTO chunks_fts(chunks_fts, rowid, text) VALUES ('delete', old.id, old.text);
END;

CREATE TRIGGER IF NOT EXISTS chunks_au AFTER UPDATE ON chunks BEGIN
    INSERT INTO chunks_fts(chunks_fts, rowid, text) VALUES ('delete', old.id, old.text);
    INSERT INTO chunks_fts(rowid, text) VALUES (new.id, new.text);
END;

CREATE TABLE IF NOT EXISTS schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


def connect(db_path: Path) -> sqlite3.Connection:
    """Open a SQLite connection with pragmas suited to a local desktop app.

    ``check_same_thread=False`` is required because Streamlit can resume a
    cached resource (see ``app.py``'s ``get_connection``) on a different
    worker thread than the one that created it. This is safe here because
    the app is single-user and Streamlit runs one script pass at a time per
    session; it is not a general-purpose multi-threaded connection pool.
    """
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")
    return conn


def initialize_schema(conn: sqlite3.Connection) -> None:
    """Create tables, indexes, and triggers if they do not already exist."""
    conn.executescript(SCHEMA_SQL)
    conn.execute(
        "INSERT OR IGNORE INTO schema_meta(key, value) VALUES ('schema_version', ?)",
        (str(SCHEMA_VERSION),),
    )
    conn.commit()


@contextmanager
def transaction(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    """Run a block of writes atomically, rolling back on any exception.

    Guarantees that a document which fails partway through parsing/chunking
    never leaves a half-written row set (e.g. a document row with no chunks,
    or chunks pointing at a deleted document).
    """
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def get_stats(conn: sqlite3.Connection) -> dict:
    """Return simple counts used by the UI (document/chunk/failure counts)."""
    doc_count = conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
    chunk_count = conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
    failed_count = conn.execute(
        "SELECT COUNT(*) FROM documents WHERE extraction_status = 'failed'"
    ).fetchone()[0]
    warning_count = conn.execute(
        "SELECT COUNT(*) FROM documents WHERE extraction_status = 'warning'"
    ).fetchone()[0]
    return {
        "document_count": doc_count,
        "chunk_count": chunk_count,
        "failed_count": failed_count,
        "warning_count": warning_count,
    }


def clear_all(conn: sqlite3.Connection) -> None:
    """Delete all documents (and, via cascade, all chunks and FTS entries)."""
    with transaction(conn):
        conn.execute("DELETE FROM documents")
