"""Local configuration management.

Configuration is persisted to ``data/config.json`` (plain UTF-8 JSON) so the
user does not need to re-enter the source folder or chunking settings every
time the application starts. Nothing here ever leaves the local machine.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, fields
from pathlib import Path

# Resolve paths relative to the project root (the folder containing app.py),
# not the current working directory, so the app behaves the same whether it
# is launched via `streamlit run app.py` from any working directory.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
LOG_DIR = PROJECT_ROOT / "logs"
LOG_PATH = LOG_DIR / "app.log"
CONFIG_PATH = DATA_DIR / "config.json"
DEFAULT_DB_PATH = DATA_DIR / "knowledge.db"

DEFAULT_CHUNK_SIZE = 1000
DEFAULT_CHUNK_OVERLAP = 150
MIN_CHUNK_SIZE = 200
MAX_CHUNK_SIZE = 4000

SUPPORTED_EXTENSIONS = {".pdf", ".pptx", ".docx", ".md", ".txt"}


@dataclass
class AppConfig:
    """User-editable application settings, persisted locally as JSON."""

    source_folder: str = ""
    db_path: str = str(DEFAULT_DB_PATH)
    chunk_size: int = DEFAULT_CHUNK_SIZE
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "AppConfig":
        known_fields = {f.name for f in fields(cls)}
        filtered = {key: value for key, value in data.items() if key in known_fields}
        return cls(**filtered)


def load_config(config_path: Path = CONFIG_PATH) -> AppConfig:
    """Load configuration from disk, creating a default file if missing."""
    if not config_path.exists():
        config = AppConfig()
        save_config(config, config_path)
        return config

    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return AppConfig()

    if not isinstance(raw, dict):
        return AppConfig()

    return AppConfig.from_dict(raw)


def save_config(config: AppConfig, config_path: Path = CONFIG_PATH) -> None:
    """Persist configuration to disk as UTF-8 JSON."""
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        json.dumps(config.to_dict(), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
