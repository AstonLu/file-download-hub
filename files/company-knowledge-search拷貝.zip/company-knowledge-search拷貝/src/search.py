"""Full-text search over indexed chunks.

This is keyword/substring search, not semantic search: a query for
"custody" only matches chunks that actually contain that text. See
``src/database.py`` for why FTS5's ``trigram`` tokenizer is used.

One important limitation of the trigram tokenizer: it cannot match query
terms shorter than 3 characters (there is no trigram to search for), which
matters a lot for Chinese, where meaningful words are frequently 1-2
characters (e.g. "台灣", "申請"). To keep those queries correct, any query
containing a short term falls back to a plain ``LIKE`` substring scan
instead of the FTS index. This trades ranking quality (occurrence counting
instead of BM25) for guaranteed correctness on short terms; at the document
counts this tool targets (hundreds to low thousands of files), a full scan
is still fast.
"""

from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass
from typing import Optional

from src.models import SearchResult

MIN_FTS_TERM_LENGTH = 3
DEFAULT_LIMIT = 50
SNIPPET_TOKEN_COUNT = 24
LIKE_SNIPPET_CONTEXT_CHARS = 60

# Private-use Unicode characters used to mark match highlights inside a
# snippet. Using these (instead of plain characters like '[' and ']')
# means the UI can safely tell "a highlight marker we inserted" apart from
# literal brackets that happen to already be in the source document text.
SNIPPET_MARK_START = "\uE000"
SNIPPET_MARK_END = "\uE001"

_TERM_PATTERN = re.compile(r'"([^"]+)"|(\S+)')


@dataclass
class SearchFilters:
    """Optional narrowing filters applied alongside the keyword query."""

    document_type: Optional[str] = None  # e.g. "pdf", "pptx", "docx", "md", "txt"
    filename_contains: Optional[str] = None
    path_contains: Optional[str] = None  # matches anywhere in the relative path
    modified_after: Optional[str] = None  # ISO date/datetime string, inclusive
    modified_before: Optional[str] = None  # ISO date/datetime string, inclusive


def parse_query_terms(raw_query: str) -> list[str]:
    """Split a raw user query into search terms.

    A double-quoted substring becomes one literal phrase term; everything
    else is split on whitespace. `Binance VASP` becomes two terms ANDed
    together; `"SBI custody"` becomes one exact-phrase term.
    """
    terms = []
    for match in _TERM_PATTERN.finditer(raw_query.strip()):
        term = match.group(1) if match.group(1) is not None else match.group(2)
        term = term.strip()
        if term:
            terms.append(term)
    return terms


def search(
    conn: sqlite3.Connection,
    raw_query: str,
    filters: Optional[SearchFilters] = None,
    limit: int = DEFAULT_LIMIT,
) -> list[SearchResult]:
    """Run a keyword search and return ranked results with source provenance."""
    terms = parse_query_terms(raw_query)
    if not terms:
        return []

    filters = filters or SearchFilters()

    if all(len(term) >= MIN_FTS_TERM_LENGTH for term in terms):
        return _search_fts(conn, terms, filters, limit)
    return _search_like(conn, terms, filters, limit)


def list_document_types(conn: sqlite3.Connection) -> list[str]:
    """Return the distinct document types currently indexed, for filter UIs."""
    rows = conn.execute(
        "SELECT DISTINCT document_type FROM chunks ORDER BY document_type"
    ).fetchall()
    return [row["document_type"] for row in rows]


def _build_filter_clause(filters: SearchFilters) -> tuple[str, list]:
    clauses = []
    params: list = []

    if filters.document_type:
        clauses.append("c.document_type = ?")
        params.append(filters.document_type)
    if filters.filename_contains:
        clauses.append("c.source_file LIKE ? ESCAPE '\\'")
        params.append(f"%{_like_escape(filters.filename_contains)}%")
    if filters.path_contains:
        clauses.append("c.relative_path LIKE ? ESCAPE '\\'")
        params.append(f"%{_like_escape(filters.path_contains)}%")
    if filters.modified_after:
        clauses.append("c.file_modified_at >= ?")
        params.append(filters.modified_after)
    if filters.modified_before:
        clauses.append("c.file_modified_at <= ?")
        params.append(filters.modified_before)

    clause_sql = (" AND " + " AND ".join(clauses)) if clauses else ""
    return clause_sql, params


def _like_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _fts_escape(term: str) -> str:
    return term.replace('"', '""')


def _search_fts(
    conn: sqlite3.Connection, terms: list[str], filters: SearchFilters, limit: int
) -> list[SearchResult]:
    match_query = " ".join(f'"{_fts_escape(term)}"' for term in terms)
    filter_sql, filter_params = _build_filter_clause(filters)

    sql = f"""
        SELECT
            c.id AS chunk_id, c.document_id, c.text, c.source_file, c.relative_path,
            c.document_type, c.page_number, c.slide_number, c.section,
            c.file_modified_at, c.indexed_at,
            bm25(chunks_fts) AS score,
            snippet(chunks_fts, 0, '{SNIPPET_MARK_START}', '{SNIPPET_MARK_END}', ' ... ', {SNIPPET_TOKEN_COUNT}) AS snippet
        FROM chunks_fts
        JOIN chunks c ON c.id = chunks_fts.rowid
        WHERE chunks_fts MATCH ?{filter_sql}
        ORDER BY rank
        LIMIT ?
    """
    params = [match_query, *filter_params, limit]
    rows = conn.execute(sql, params).fetchall()
    return [_row_to_result(row, snippet=row["snippet"], score=float(row["score"])) for row in rows]


def _search_like(
    conn: sqlite3.Connection, terms: list[str], filters: SearchFilters, limit: int
) -> list[SearchResult]:
    like_clauses = ["c.text LIKE ? ESCAPE '\\'" for _ in terms]
    like_params = [f"%{_like_escape(term)}%" for term in terms]
    filter_sql, filter_params = _build_filter_clause(filters)

    # No index-backed ranking available on this path, so pull a generous
    # candidate pool ordered by recency and rank by term-occurrence count
    # in Python; the candidate pool is capped well above `limit` so ranking
    # still has enough to work with even on a large corpus.
    candidate_pool = max(limit * 10, 500)
    sql = f"""
        SELECT
            c.id AS chunk_id, c.document_id, c.text, c.source_file, c.relative_path,
            c.document_type, c.page_number, c.slide_number, c.section,
            c.file_modified_at, c.indexed_at
        FROM chunks c
        WHERE {' AND '.join(like_clauses)}{filter_sql}
        ORDER BY c.indexed_at DESC
        LIMIT ?
    """
    params = [*like_params, *filter_params, candidate_pool]
    rows = conn.execute(sql, params).fetchall()

    results = []
    for row in rows:
        text = row["text"]
        occurrence_count = sum(text.lower().count(term.lower()) for term in terms)
        snippet = _make_snippet(text, terms)
        # Negative so that, like bm25, a lower score means "more relevant"
        # and results sort consistently across both search paths.
        results.append(_row_to_result(row, snippet=snippet, score=float(-occurrence_count)))

    results.sort(key=lambda r: r.score)
    return results[:limit]


def _make_snippet(text: str, terms: list[str], context_chars: int = LIKE_SNIPPET_CONTEXT_CHARS) -> str:
    lowered = text.lower()
    for term in terms:
        idx = lowered.find(term.lower())
        if idx == -1:
            continue
        start = max(0, idx - context_chars)
        end = min(len(text), idx + len(term) + context_chars)
        prefix = " ... " if start > 0 else ""
        suffix = " ... " if end < len(text) else ""
        highlighted = text[idx : idx + len(term)]
        return (
            f"{prefix}{text[start:idx]}{SNIPPET_MARK_START}{highlighted}{SNIPPET_MARK_END}"
            f"{text[idx + len(term):end]}{suffix}"
        )

    truncated = text[: context_chars * 2]
    return truncated + (" ..." if len(text) > len(truncated) else "")


def _row_to_result(row: sqlite3.Row, snippet: str, score: float) -> SearchResult:
    return SearchResult(
        chunk_id=row["chunk_id"],
        document_id=row["document_id"],
        text=row["text"],
        snippet=snippet,
        source_file=row["source_file"],
        relative_path=row["relative_path"],
        document_type=row["document_type"],
        page_number=row["page_number"],
        slide_number=row["slide_number"],
        section=row["section"],
        file_modified_at=row["file_modified_at"],
        indexed_at=row["indexed_at"],
        score=score,
    )
