"""Shared data model definitions used across the ingestion and search pipeline.

Every dataclass here exists to carry source-traceability information end to
end: from raw parser output, through chunking, into SQLite, and back out as
a search result. No layer is allowed to "forget" where a piece of text came
from.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ExtractedUnit:
    """A single normalized unit of extracted text with source provenance.

    One unit typically corresponds to one PDF page, one PPTX slide, or one
    paragraph/section of a Word or text document. Chunking is always applied
    within a single unit, never across units, so a chunk can never mix text
    from two different pages or slides.
    """

    text: str
    page_number: Optional[int] = None
    slide_number: Optional[int] = None
    section: Optional[str] = None


@dataclass
class ParseResult:
    """The result of parsing a single source document."""

    units: list[ExtractedUnit] = field(default_factory=list)
    status: str = "ok"  # "ok" | "warning" | "failed"
    message: Optional[str] = None


@dataclass
class Chunk:
    """A chunk of text ready to be written to the database and search index."""

    text: str
    chunk_index: int
    page_number: Optional[int] = None
    slide_number: Optional[int] = None
    section: Optional[str] = None


@dataclass
class DocumentMeta:
    """Filesystem-level metadata for a document discovered by the scanner."""

    absolute_path: str
    relative_path: str
    filename: str
    extension: str
    file_size: int
    file_modified_at: str
    content_hash: str


@dataclass
class SyncReport:
    """Summary of a sync (incremental indexing) operation."""

    new: int = 0
    updated: int = 0
    deleted: int = 0
    unchanged: int = 0
    failed: int = 0
    failures: list[tuple[str, str]] = field(default_factory=list)
    warnings: list[tuple[str, str]] = field(default_factory=list)


@dataclass
class SearchResult:
    """A single ranked search result with full source provenance."""

    chunk_id: int
    document_id: int
    text: str
    snippet: str
    source_file: str
    relative_path: str
    document_type: str
    page_number: Optional[int]
    slide_number: Optional[int]
    section: Optional[str]
    file_modified_at: Optional[str]
    indexed_at: str
    score: float
