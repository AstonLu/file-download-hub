"""company-knowledge-search: local-first document indexing and search."""
