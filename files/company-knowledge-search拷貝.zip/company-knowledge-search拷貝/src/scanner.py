"""Filesystem scanning and change detection for the source folder.

Compares the current state of the source folder against the document
registry in SQLite to classify each file as new / modified / deleted /
unchanged. SHA-256 content hash is the source of truth for "did this file
actually change"; file size and modified-time are used as a fast precheck
so an unchanged file (the common case on a repeated sync) never needs to be
re-hashed.
"""

from __future__ import annotations

import hashlib
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from src.models import DocumentMeta

HASH_CHUNK_SIZE = 1024 * 1024  # 1 MiB, keeps memory use flat for large files


@dataclass
class ScanPlan:
    """The outcome of comparing the source folder against the registry."""

    to_index: list[DocumentMeta] = field(default_factory=list)
    to_delete: list[str] = field(default_factory=list)
    unchanged: list[str] = field(default_factory=list)
    skipped: list[tuple[str, str]] = field(default_factory=list)


def compute_sha256(file_path: Path) -> str:
    """Compute the SHA-256 hash of a file's contents, streamed in chunks."""
    digest = hashlib.sha256()
    with file_path.open("rb") as fh:
        while True:
            block = fh.read(HASH_CHUNK_SIZE)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def scan_source_folder(
    source_folder: Path,
    supported_extensions: set[str],
    conn: sqlite3.Connection,
) -> ScanPlan:
    """Walk the source folder and classify every supported file.

    Files with unsupported extensions are silently skipped (they were never
    offered to the user as indexable); files that exist but cannot be
    stat'd or read are reported in ``ScanPlan.skipped`` instead of raising.
    """
    existing_rows = conn.execute(
        "SELECT relative_path, content_hash, file_size, file_modified_at FROM documents"
    ).fetchall()
    existing = {row["relative_path"]: row for row in existing_rows}

    seen_relative_paths: set[str] = set()
    plan = ScanPlan()

    for file_path in sorted(source_folder.rglob("*")):
        if not file_path.is_file():
            continue
        extension = file_path.suffix.lower()
        if extension not in supported_extensions:
            continue

        relative_path = file_path.relative_to(source_folder).as_posix()
        seen_relative_paths.add(relative_path)

        try:
            stat = file_path.stat()
        except OSError as exc:
            plan.skipped.append((relative_path, f"Could not access file: {exc}"))
            continue

        modified_at = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat()
        previous = existing.get(relative_path)

        if (
            previous is not None
            and previous["file_size"] == stat.st_size
            and previous["file_modified_at"] == modified_at
        ):
            plan.unchanged.append(relative_path)
            continue

        try:
            content_hash = compute_sha256(file_path)
        except OSError as exc:
            plan.skipped.append((relative_path, f"Could not read file: {exc}"))
            continue

        if previous is not None and previous["content_hash"] == content_hash:
            # size/mtime looked different (e.g. a re-save with identical
            # content) but the actual bytes are unchanged -- skip re-parsing
            plan.unchanged.append(relative_path)
            continue

        plan.to_index.append(
            DocumentMeta(
                absolute_path=str(file_path),
                relative_path=relative_path,
                filename=file_path.name,
                extension=extension,
                file_size=stat.st_size,
                file_modified_at=modified_at,
                content_hash=content_hash,
            )
        )

    plan.to_delete = [rel for rel in existing if rel not in seen_relative_paths]
    return plan
